# E2EE design proposal — NOT IMPLEMENTED

## Current truth

No E2EE library, device private keys, encrypted envelopes or key exchange is shipped. Server stores message/file plaintext. Client explicitly discloses this. `REQUIRE_E2EE=true` denies new message/attachment creation, rather than choosing an insecure fallback. Existing data is still readable to the server. No cipher or security protocol is invented here.

## Proposed next release boundary

Select a maintained, independently reviewed Signal/MLS implementation with browser support and licensing/maintenance review. Perform a threat model and integration spike BEFORE choosing exact dependencies. Device identity keys must be generated client-side; private key material must never be uploaded plaintext. Prefer non-extractable platform-backed storage where supported and evaluate browser compromise, origin changes, XSS and malicious server code as threats. A JavaScript web app cannot promise protection from a fully malicious delivered client.

Explicitly model account->devices with public identity/prekey metadata, authenticated device additions, verified fingerprints/QR comparison, visible key-change warnings, device revocation and explicit rekeying. Each message envelope binds protocol/version/conversation/sender-device/recipient-device identifiers using the chosen protocol's authenticated metadata. Use that protocol's established forward-secrecy/ratchet or group epoch mechanisms, not bespoke AES glue. Server envelope size/resource bounds and membership checks remain mandatory.

Attachments require client-generated per-file encryption under the selected mature construction, ciphertext storage and authenticated key distribution inside encrypted messages; filename/type/preview leakage must be minimized. Ciphertext cannot use existing plaintext magic-byte scanning. A separate explicit encrypted-media endpoint with different abuse assumptions is needed; do NOT silently reuse current upload claims.

Local-only search index and explicit user-approved export/translation; notifications default to generic metadata. Encrypted backups require a user-held recovery secret, documented loss behavior and versioned format. Losing all devices without recovery means losing decryptability. New devices receive keys/history only through explicit verified device handoff or user-unlocked backup, never a hidden server master key. Administrators see routing metadata, not message keys or content.

Remove/disable server plaintext search and content previews for E2EE conversations; do not maintain an invisible plaintext mirror. Migration from server-readable history must be opt-in, distinguish legacy content and not retroactively label it encrypted. Verify protocol vectors, tamper/replay/out-of-order/lost-device cases, cross-device and group rotation with security specialists before any E2EE claim. This proposal is not cryptographic assurance.
