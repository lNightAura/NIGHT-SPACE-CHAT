# API and event contract

All routes under /api. JSON errors {error,code}; no stack traces. Authenticated endpoints require cookie. Writes require exact configured Origin. Limits may return 429 with Retry-After. All IDs are opaque UUIDs unless documented.
GET /health, /ready; GET /capabilities
POST /auth/register {username,displayName,password,captchaToken?}; POST /auth/login {username,password,captchaToken?}; POST /auth/logout; POST /auth/logout-all
GET /me; PATCH /me {displayName?,bio?,theme?,accent?,readReceipts?,typingVisible?}; POST /me/password {currentPassword,newPassword}; GET /me/export; DELETE /me {password}
GET /sessions; DELETE /sessions/:id
GET /users?username=exact; POST /blocks {userId}; DELETE /blocks/:id; GET /blocks; POST /reports {targetId,reason}
GET /conversations; POST /conversations {userIds,title?,kind}; PATCH /conversations/:id {pinned?,archived?,muted?,folder?}; POST /conversations/:id/members {userId}; DELETE /conversations/:id/members/:userId (group admin)
GET /conversations/:id/messages?cursor=opaque&search=text; POST .../messages {body,clientId,replyToId?,attachmentId?}; POST .../read
PATCH /messages/:id {body}; DELETE /messages/:id?scope=everyone|me; POST /messages/:id/reactions {emoji}
POST /conversations/:id/attachments multipart file; GET /attachments/:id
GET /admin/metrics (admin only); GET /admin/reports (admin only)
Socket auth is session cookie + origin. Client: typing {conversationId}, message.received {messageId}. Server: message.new, conversation.updated, messages.updated, typing. All event payloads are untrusted and validated. Typing is transient and throttled. Socket reconnect triggers HTTP refresh, so missed invalidations do not lose stored messages.
