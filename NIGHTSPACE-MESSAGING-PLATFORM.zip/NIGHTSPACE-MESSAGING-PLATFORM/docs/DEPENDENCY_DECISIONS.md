# Dependency decisions

Node 22 runtime and npm workspaces. Next 16.4.5 with React 19, Express 5, Socket.IO 4.8, Prisma/client 6.19.3 remain mutually tested through actual builds and integration/browser workflows. Root lockfile is authoritative; version ranges are not claims that every possible future resolution will work. Prisma major upgrade was intentionally not applied merely to remove dev-tool advisories.

An initial npm 10.9.9 optional-peer resolver crash required explicit `legacy-peer-deps=true` in .npmrc. Final dependency resolution/clean installation is recorded. This is not a reason to ignore peer compatibility: lint, schemas, TypeScript, runtime unit/integration and actual optimized frontend workflows were executed.

Dependency scanning initially flagged dev-tool transitive deepmerge-ts (<8) through Prisma configuration and minimatch (<11.0.1) through TypeScript/ESLint. Root overrides pin deepmerge-ts 8.0.2 and minimatch 11.0.5; clean resolution confirms them. Prisma generate/validate/deploy, ESLint, TypeScript and production builds/tests were rerun. ESLint was moved to the current supported 10.x line. These overrides cross original transitive major ranges: maintainers should reassess against upstream updates rather than blindly retaining them forever. No npm audit --force was used.

Runtime dotenv is explicitly declared in API/web dependencies, not solely dev tooling. Native Argon2/sharp platform packages need supported OS/runtime or build prerequisites. npm audit reflects the current registry snapshot, not proof of no unknown vulnerability. Final raw reports in evidence distinguish full and runtime-only audits.
