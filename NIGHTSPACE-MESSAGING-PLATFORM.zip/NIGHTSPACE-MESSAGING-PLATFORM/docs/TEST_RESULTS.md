# Actual verification results — 2026-11-07

Tested current development milestone, not the whole master specification and not production certification. Commands executed in Linux with Node 22.23.4 / npm 10.9.9, PostgreSQL 16 and Redis DB 15. Browser tests ran optimized Next frontend plus development-security-mode API.

| Check | Final result | Evidence |
|---|---|---|
| clean-install | PASS | `docs/evidence/clean-install.txt` |
| prisma-validate | PASS | `docs/evidence/prisma-validate.txt` |
| prisma-generate | PASS | `docs/evidence/prisma-generate.txt` |
| migrations | PASS | `docs/evidence/migrations.txt` |
| environment | PASS | `docs/evidence/environment.txt` |
| format | PASS | `docs/evidence/format.txt` |
| format-check | PASS | `docs/evidence/format-check.txt` |
| lint | PASS | `docs/evidence/lint.txt` |
| typecheck | PASS | `docs/evidence/typecheck.txt` |
| unit | PASS | `docs/evidence/unit.txt` |
| integration | PASS | `docs/evidence/integration.txt` |
| production-build | PASS | `docs/evidence/production-build.txt` |
| browser | PASS | `docs/evidence/browser.txt` |
| runtime-audit | PASS | `docs/evidence/runtime-audit.txt` |
| full-audit | PASS | `docs/evidence/full-audit.txt` |
| production-startup-guard | PASS | `docs/evidence/production-guard.txt` |

## Automated test totals
- Unit: 11 tests.
- Integration: 26 tests with real PostgreSQL, Redis and Socket.IO. External CAPTCHA provider responses mocked.
- Browser: 3 Chromium workflows (desktop two-user realtime/RTL/XSS literal/reply/reload/reconnect, all 13 themes, mobile saved chat/privacy).
- Total: 40 test cases. Counts and pass/fail lines must be read with the above final exit statuses and raw logs.

## Build and schema
Shared contracts, API JavaScript and optimized Next production build executed. Two SQL migrations applied in the test database; generated Prisma client and schema validation executed. Production startup with insecure/missing production settings was intentionally rejected; the negative test is a pass only if it fails closed. A production build is not a live production deployment.

## Security scan
Both runtime-only and full development dependency audit commands executed. Exact registry findings are preserved as JSON in the corresponding evidence .txt files. No known vulnerabilities reported is not a guarantee of security. Dev dependency overrides are documented in DEPENDENCY_DECISIONS.md.

## Not executed / not claimed
Windows 11 execution, Docker daemon/Compose startup in this sandbox (native local Postgres/Redis were used), actual Turnstile challenges/real keys, browser engines beyond Chromium, E2EE cryptographic tests (feature absent), voice/WebRTC/TURN tests (feature absent), production TLS/WAF/CDN, destructive DDoS/load/chaos tests, independent ASVS/security/accessibility audit, and VPS backup/restore/deployment.

## Earlier issues fixed
Optional-peer npm resolver crash; palette test expected the wrong token count; mocked Response reuse; missing browser shared libraries; socket trailing slash forwarding; message-menu viewport clipping; asynchronous checkbox state; development-tool audit advisories. Final results above are from reruns after fixes. Synthetic screenshots under docs/screenshots show the running app, not AI-generated mockups.
