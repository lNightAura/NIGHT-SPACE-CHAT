# Roadmap and release boundary

1. Foundation: monorepo, migrations, local services, configuration, architecture.
2. Working core: accounts/sessions, profiles, direct/group/saved conversations, text, replies/edit/delete/react, private attachment foundation, cursor history, retry idempotency, receipts, real-time invalidation.
3. Security baseline: CSRF/origin, password reauth, revocation, rate counters, CAPTCHA server verification, RBAC, blocking/reporting, documented threat boundaries.
4. Premium UI: Luxury Cream and 12 further token themes, gallery, simple accent editor, responsive conversation/chat/settings, Unicode and reduced motion.
   Deferred release work (not claimed): audited E2EE protocol/device lifecycle; WebRTC call state machine and TURN integration; voice recording; TOTP/passkeys/recovery; polls/scheduling/stories; fully featured custom/per-chat theme editor; avatar uploads/cropping; notification delivery/push, admin operational UI, adaptive abuse detection, distributed presence, disappearing-message jobs, security penetration review and multi-browser voice tests.
   The ZIP is a coherent development milestone, not completion of the entire master specification. See PROJECT_STATUS and TEST_RESULTS for evidence.
