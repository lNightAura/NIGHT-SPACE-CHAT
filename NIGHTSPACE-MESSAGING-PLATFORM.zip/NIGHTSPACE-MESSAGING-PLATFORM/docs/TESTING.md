# Testing and reproducibility

## Executed environment

Node 22.23.4 / npm 10.9.9, Linux, PostgreSQL 16 local service and Redis local service DB 15. Prisma schema validated; migration applied to fresh nightspace_test; unit, integration and Chromium browser workflows executed. Windows, actual Turnstile, actual HTTPS deployment, Safari/Firefox and TURN/voice were not tested. See TEST_RESULTS for final numbers and raw logs.

## Routine checks (no reset flag)

```powershell
npm ci
npm run db:generate
npm run build -w @nightspace/shared
npm run lint
npm run typecheck
npm test
npm run build
npm audit --omit=dev
```

Unit tests use parsers/configuration without connecting database/Redis. Supply .env for app-specific values or the test config's unused local defaults apply.

## Isolated Windows integration test environment

Stop development servers. Create a dedicated test database while the Compose postgres service is running. This example uses the dedicated local Compose role, NOT a production role:

```powershell
docker compose exec postgres createdb -U nightspace nightspace_test
# Replace the password placeholder below with your own local Compose password.
$env:DATABASE_URL = "postgresql://nightspace:YOUR_LOCAL_PASSWORD@localhost:55432/nightspace_test?connection_limit=10&pool_timeout=10"
$env:REDIS_URL = "redis://localhost:56379/15"
$env:WEB_ORIGIN = "http://localhost:3100"
$env:NODE_ENV = "test"
$env:CAPTCHA_REQUIRED = "false"
$env:REQUIRE_E2EE = "false"
$env:NIGHTSPACE_TEST_ALLOW_RESET = "true"
npm run db:migrate
npm run test:integration
npx playwright install chromium
npm run build
npm run test:e2e
Remove-Item Env:NIGHTSPACE_TEST_ALLOW_RESET
Remove-Item Env:DATABASE_URL
Remove-Item Env:REDIS_URL
Remove-Item Env:WEB_ORIGIN
Remove-Item Env:NODE_ENV
Remove-Item Env:CAPTCHA_REQUIRED
Remove-Item Env:REQUIRE_E2EE
```

If test DB already exists, do not recreate it blindly; confirm it is disposable. Linux may need `npx playwright install --with-deps chromium` (operator-approved system dependencies). Ports 3100/4100 must be free. Browser suite starts its own API (development security mode) and optimized Next server (production frontend mode); this is NOT a production-security deployment test.

Integration refuses unless reset guard is true, database name ends `_test`, and Redis URL ends `/15`. Browser tests have the same guard. These checks reduce accidental destruction but do not replace correct environment selection. Integration resets users, conversations, security events and DB 15. Browser clears DB 15 before each test. **Do not share these resources with users.** They are not load/DDoS tests.

## Evidence semantics

CAPTCHA integration tests mock external fetch responses, validate missing token/hostname/action/replay guards; they do not prove provider keys or network integration work. Byte-signature tests use minimal synthetic fixtures, not exhaustive malicious file analysis. Pagination fixture is 125 messages with tied timestamps; continuity workflow is 75 real sends across reset transient windows, not a capacity benchmark. Socket tests use real HTTP server/Socket.IO/Redis and check authentication, membership fanout, receipts, reconnect and revocation. Browser tests assert realtime connected through Next, literal text rendering, two contexts, reply, reload/offline synchronization, 13 theme previews/save/reload and mobile saved chat/privacy toggle.

No automated test certifies full ASVS compliance, complete accessibility, unlimited physical storage, production load tolerance or cryptographic security. Unimplemented features are not hidden behind skipped tests.
