# NIGHTSPACE architecture — phase delivery

## Boundaries

Next.js App Router + React/TypeScript browser client; structured Express/TypeScript REST and Socket.IO service; Prisma/PostgreSQL durable state; Redis distributed transient rate counters and Socket.IO adapter. Browser talks to same-origin /api and /socket.io; Next rewrites these in development and Nginx proxies them in deployment. API binds loopback by default. Single VPS, separate app ports, no deployment performed.

## Authentication

Argon2id passwords. Random 256-bit session token in HTTP-only SameSite=Lax cookie; only SHA-256 token digest in database. Fixed expiration; explicit login rotation, revoke by session ID, password changes revoke all other sessions. Exact Origin check on all browser writes, including login; WebSocket requires same Origin, cookie and live session. No authentication localStorage. Reauthentication for password changes and account deletion. Session revocations disconnect sockets. Redis quotas are short-window anti-abuse, not product message quotas.

## Data and authorization

Users -> sessions/preferences, conversation -> members/messages; membership revalidated at every REST action and socket event. Direct conversation canonical unique key prevents duplicate private chats. Composite sequence cursor (createdAt,id) handles timestamp ties; unique sender/clientId ensures safe retry. Conversation/member creation uses a nested atomic write; unique indexes arbitrate duplicate retries. Explicit transactions protect password and account operations. Messages are server-readable in this phase: NOT E2EE. A visible disclosure is mandatory; a configuration guard can disable all server-readable sending. No silent encrypted/plaintext mode switch exists.

## Realtime

REST writes are authoritative, sockets carry invalidation/new-message events. Session-authenticated user rooms only: server calculates room recipients from members; no client-selected arbitrary room joins. Reconnect refetches durable history; no promise of durable event queue. Read watermark is per member; message.received acknowledges delivery. Redis adapter distributes events, but presence remains intentionally unimplemented.

## Files

Bounded multipart -> magic bytes/type checks -> random private disk key -> metadata. Download queries membership before reading, content disposition attachment, nosniff. No public upload mount. Attachment upload is linked to a conversation before messages may reference it. No SVG/HTML/executables. Antimalware external scanning is not present; production file upload disabled unless explicitly enabled.

## Security

Zod validation, Prisma bound parameters, Helmet headers, exact origin, Redis atomic counters, safe error responses, no request bodies or content logs. Production startup fails without CAPTCHA and secure-cookie configuration. No custom cryptography. CSP on Next HTML (development relaxations documented). Request bounds/timeouts, graceful close, RBAC metrics/report endpoints. No ASVS certification claimed.

## Infrastructure / limits

PostgreSQL 16 + Redis 7, Node 22. Database connection pool bounded in URL. No infinite capacity claim. Redis failure fails sensitive API operations closed. Backups require encrypted external destinations. Local disk uploads require shared storage before horizontal scaling. No automatic origin IP trust or global firewall changes.

## Directory structure

apps/web UI, apps/api server, packages/shared validation/themes, prisma schema/migrations/seed, tests unit/integration/browser, infrastructure proxy/process examples, scripts validation/packaging, docs decisions/API/security/roadmap.
