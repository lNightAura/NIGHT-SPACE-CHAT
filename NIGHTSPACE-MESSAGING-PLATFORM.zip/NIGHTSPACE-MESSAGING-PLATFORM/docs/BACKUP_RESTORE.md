# Backup and restore runbook

**Never test restores against a live database.** Back up only NIGHTSPACE resources; do not touch other VPS apps. Review storage capacity and encrypt backups before off-host transfer.

Use PostgreSQL `pg_dump --format=custom` with `--no-owner --no-acl` against the dedicated database. Provide password via protected `PGPASSFILE` or an interactive prompt, not command-line arguments/shell history. The included PowerShell script invokes `pg_dump` directly to a file (not a text pipeline that corrupts binary backups), verifies exit status and creates a private-upload archive. It does not encrypt for you; your established encryption tool must secure both before transfer.

Back up database, upload directory and environment/credential recovery materials separately. Coordinate a maintenance window or snapshot strategy for consistency across DB/file storage. Redis contains session-independent transient rate/replay state and pub/sub, not messages; loss of rate state weakens short-term abuse controls. Sessions are in PostgreSQL, so a restored old DB can resurrect sessions: revoke all restored sessions before cutover. Rotate CAPTCHA/operator secrets after an incident when appropriate. No app encryption keys exist yet.

Restore drill (operator preparation):

```bash
# TARGET must be a NEW, isolated, non-production database.
pg_restore --no-owner --no-acl --dbname="$RESTORE_DATABASE_URL" /private/backup/nightspace.dump
```

Create the target DB first using your normal DBA workflow. Never add `--clean` to a live target. Extract upload archive to a new private directory, set app-only permissions, point a separate staging instance to it, run liveness/readiness and fixture-based checks, inspect counts/access controls and verify known attachment downloads. Do not send restored user messages or outbound notifications. Do not run destructive integration tests on the restored data. Only a verified restore and approved cutover can replace production resources.

Record backup times, encryption/key custody, checksum, restore verification, RPO/RTO, retention and deletion policy. Example policy is not supplied as a guarantee: choose it according to your legal and operational requirements. Deleted messages/accounts can persist in retained backups until expiry; communicate this clearly. Test all retention and restore procedures operationally before launch. No backup/restore against a VPS or off-host store was executed here.
