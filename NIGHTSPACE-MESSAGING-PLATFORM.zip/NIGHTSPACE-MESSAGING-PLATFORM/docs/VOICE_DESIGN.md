# Audio calls — deferred, no working implementation

No WebRTC peer connections, signaling events, call metadata/history, TURN credentials, audio UI, voice recorder or video/screen-share features are implemented. Microphone/camera access is disabled by Permissions-Policy in this milestone. This is deliberate: a token UI would misrepresent verification.

Future design: authenticated membership-bound call IDs and server-state machine (offered/ringing/accepted/rejected/ended/missed/failed); bounded offers and candidate relay; anti-abuse per-account initiation/TURN credential throttles; STUN discovery and isolated coturn with short-lived credentials. Never record by default. Encrypted WebRTC transport is not equivalent to verified application-layer E2EE identity. Signaling must bind identity/device/session and should be part of the E2EE review. Calls remain separate from message persistence.

Browser tests must cover microphone permission denial/grant, multiple tabs/devices, busy state, reject/end/missed call race cases, network loss/ICE restart/TURN fallback, Safari/Firefox/mobile compatibility, mute/input/output controls and quality/duration. Infrastructure template alone verifies none of these. No TURN deployment was performed.
