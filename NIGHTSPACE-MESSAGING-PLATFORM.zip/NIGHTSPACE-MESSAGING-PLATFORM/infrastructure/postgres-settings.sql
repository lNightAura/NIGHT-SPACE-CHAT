-- Operator reference only: replace role name with NIGHTSPACE's dedicated role.
-- Do not apply globally to other applications or existing bot databases.
ALTER ROLE nightspace SET statement_timeout = '15s';
ALTER ROLE nightspace SET idle_in_transaction_session_timeout = '15s';
-- Set connection_limit in DATABASE_URL; configure server connection resources independently.
