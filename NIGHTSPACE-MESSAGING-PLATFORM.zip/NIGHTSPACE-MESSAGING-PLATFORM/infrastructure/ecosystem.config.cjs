// EDIT cwd and ports only after inventorying existing applications. Never stop all PM2 apps.
const root = process.env.NIGHTSPACE_ROOT || require('node:path').resolve(__dirname, '..');
module.exports={apps:[
 {name:'nightspace-api',cwd:root,script:'apps/api/dist/index.js',instances:1,exec_mode:'fork',max_memory_restart:'512M',kill_timeout:12000,env_production:{NODE_ENV:'production',API_HOST:'127.0.0.1',API_PORT:'4100'}},
 {name:'nightspace-web',cwd:require('node:path').join(root,'apps/web'),script:'../../node_modules/next/dist/bin/next',args:'start --hostname 127.0.0.1 -p 3100',instances:1,exec_mode:'fork',max_memory_restart:'768M',env_production:{NODE_ENV:'production'}}
]};
