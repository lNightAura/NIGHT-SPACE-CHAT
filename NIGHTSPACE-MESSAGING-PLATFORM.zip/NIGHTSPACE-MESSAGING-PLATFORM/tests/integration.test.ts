import {
  beforeAll,
  afterAll,
  beforeEach,
  describe,
  it,
  expect,
  vi,
} from "vitest";
import request from "supertest";
import { randomUUID } from "node:crypto";
import { createServer, type Server } from "node:http";
import { io as client, type Socket } from "socket.io-client";
import { createApp } from "../apps/api/src/app.js";
import { db, redis } from "../apps/api/src/db.js";
import { config } from "../apps/api/src/config.js";
import { setupRealtime } from "../apps/api/src/realtime.js";
import { digest } from "../apps/api/src/security.js";
const app = createApp(),
  origin = config.WEB_ORIGIN,
  pass = "integration-only-passphrase";
type Agent = ReturnType<typeof request.agent>;
type TestUser = { id: string; agent: Agent; cookie: string; username: string };
let a: TestUser,
  b: TestUser,
  c: TestUser,
  chatId: string,
  server: Server,
  port: number,
  closeSockets: () => Promise<void>;
async function register(username: string) {
  const agent = request.agent(app);
  const res = await agent
    .post("/api/auth/register")
    .set("Origin", origin)
    .send({ username, displayName: username, password: pass });
  expect(res.status).toBe(201);
  return {
    id: res.body.id as string,
    username,
    agent,
    cookie: (res.headers["set-cookie"] as unknown as string[])[0].split(";")[0],
  };
}
async function send(
  user: TestUser,
  body = "Hello 🌙 سلام",
  clientId = randomUUID(),
) {
  return user.agent
    .post(`/api/conversations/${chatId}/messages`)
    .set("Origin", origin)
    .send({ body, clientId });
}
async function connect(cookie: string) {
  return new Promise<Socket>((resolve, reject) => {
    const s = client("http://127.0.0.1:" + port, {
      transports: ["websocket"],
      extraHeaders: { Origin: origin, Cookie: cookie },
      reconnection: false,
      timeout: 3000,
    });
    s.on("connect", () => resolve(s));
    s.on("connect_error", (e) => {
      s.disconnect();
      reject(e);
    });
  });
}
beforeAll(async () => {
  if (
    process.env.NIGHTSPACE_TEST_ALLOW_RESET !== "true" ||
    !new URL(config.DATABASE_URL).pathname.endsWith("_test") ||
    !config.REDIS_URL.endsWith("/15")
  )
    throw new Error(
      "Integration reset requires NIGHTSPACE_TEST_ALLOW_RESET=true, *_test database and Redis DB 15. NEVER point this suite at production.",
    );
  await db.$connect();
  await redis.connect();
  server = createServer(app);
  closeSockets = await setupRealtime(server);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  port = (server.address() as { port: number }).port;
});
beforeEach(async () => {
  await redis.flushdb();
  await db.securityEvent.deleteMany();
  await db.user.deleteMany();
  await db.conversation.deleteMany();
  a = await register("test_alice");
  b = await register("test_bob");
  c = await register("test_charlie");
  const res = await a.agent
    .post("/api/conversations")
    .set("Origin", origin)
    .send({ userIds: [b.id] });
  expect(res.status).toBe(201);
  chatId = res.body.id;
});
afterAll(async () => {
  vi.restoreAllMocks();
  if (closeSockets) await closeSockets();
  if (server)
    await new Promise<void>((resolve) => server.close(() => resolve()));
  await db.$disconnect();
  if (redis.status !== "end") await redis.quit();
});
describe("authentication and sessions", () => {
  it("uses Argon2id and HttpOnly cookie without exposing hash", async () => {
    const row = await db.user.findUniqueOrThrow({ where: { id: a.id } });
    expect(row.passwordHash).toMatch(/^\$argon2id\$/);
    const me = await a.agent.get("/api/me");
    expect(me.body.passwordHash).toBeUndefined();
    const res = await request(app)
      .post("/api/auth/login")
      .set("Origin", origin)
      .send({ username: a.username, password: pass });
    expect(res.status).toBe(200);
    expect(res.headers["set-cookie"][0]).toContain("HttpOnly");
    expect(res.headers["set-cookie"][0]).toContain("SameSite=Lax");
    const token = res.headers["set-cookie"][0].split(";")[0].split("=")[1];
    expect(
      await db.session.findUnique({ where: { tokenHash: digest(token) } }),
    ).not.toBeNull();
  });
  it("does not enumerate wrong login and rejects duplicates", async () => {
    for (const username of ["missing", a.username]) {
      const res = await request(app)
        .post("/api/auth/login")
        .set("Origin", origin)
        .send({ username, password: "incorrect-passphrase" });
      expect(res.status).toBe(401);
      expect(res.body.error).toBe("Invalid username or password");
    }
    const res = await request(app)
      .post("/api/auth/register")
      .set("Origin", origin)
      .send({ username: a.username, displayName: "duplicate", password: pass });
    expect(res.status).toBe(409);
  });
  it("rejects expired session and supports revocation", async () => {
    await db.session.updateMany({
      where: { userId: a.id },
      data: { expiresAt: new Date(0) },
    });
    expect((await a.agent.get("/api/me")).status).toBe(401);
    const sessions = await b.agent.get("/api/sessions");
    expect(sessions.body[0].current).toBe(true);
    expect(
      (
        await b.agent
          .delete("/api/sessions/" + sessions.body[0].id)
          .set("Origin", origin)
      ).status,
    ).toBe(204);
    expect((await b.agent.get("/api/me")).status).toBe(401);
  });
  it("logout and logout-all revoke persistent sessions", async () => {
    expect(
      (await a.agent.post("/api/auth/logout").set("Origin", origin)).status,
    ).toBe(204);
    expect((await a.agent.get("/api/me")).status).toBe(401);
    await b.agent.post("/api/auth/logout-all").set("Origin", origin);
    expect(await db.session.count({ where: { userId: b.id } })).toBe(0);
  });
  it("changes password with reauthentication and revokes other devices", async () => {
    const other = request.agent(app);
    await other
      .post("/api/auth/login")
      .set("Origin", origin)
      .send({ username: a.username, password: pass });
    expect(
      (
        await a.agent.post("/api/me/password").set("Origin", origin).send({
          currentPassword: "wrong",
          newPassword: "new-long-passphrase",
        })
      ).status,
    ).toBe(401);
    expect(
      (
        await a.agent
          .post("/api/me/password")
          .set("Origin", origin)
          .send({ currentPassword: pass, newPassword: "new-long-passphrase" })
      ).status,
    ).toBe(204);
    expect((await other.get("/api/me")).status).toBe(401);
    expect((await a.agent.get("/api/me")).status).toBe(200);
  });
  it("requires exact origin on writes, including login", async () => {
    for (const invalid of ["https://evil.example", "null", ""]) {
      let req = a.agent.post("/api/auth/logout");
      if (invalid) req = req.set("Origin", invalid);
      expect((await req).status).toBe(403);
    }
    expect(
      (
        await request(app)
          .post("/api/auth/login")
          .send({ username: a.username, password: pass })
      ).status,
    ).toBe(403);
  });
  it("enforces endpoint rate limits without daily message quotas", async () => {
    for (let i = 0; i < 15; i++)
      await request(app)
        .post("/api/auth/login")
        .set("Origin", origin)
        .send({ username: "not_found", password: "bad" });
    expect(
      (
        await request(app)
          .post("/api/auth/login")
          .set("Origin", origin)
          .send({ username: "not_found", password: "bad" })
      ).status,
    ).toBe(429);
  });
  it("exports authored data without session hashes and deletes with reauthentication", async () => {
    await send(a, "export this");
    const res = await a.agent.get("/api/me/export");
    expect(res.status).toBe(200);
    expect(res.body.messages[0].body).toBe("export this");
    expect(JSON.stringify(res.body)).not.toContain("passwordHash");
    expect(JSON.stringify(res.body)).not.toContain("tokenHash");
    expect(
      (
        await a.agent
          .delete("/api/me")
          .set("Origin", origin)
          .send({ password: "wrong" })
      ).status,
    ).toBe(401);
    expect(
      (
        await a.agent
          .delete("/api/me")
          .set("Origin", origin)
          .send({ password: pass })
      ).status,
    ).toBe(204);
    expect((await a.agent.get("/api/me")).status).toBe(401);
  });
});
describe("persistent authorized messaging", () => {
  it("stores Unicode and prevents identity spoofing and IDOR", async () => {
    const sent = await send(a);
    expect(sent.status).toBe(201);
    expect(sent.body.senderId).toBe(a.id);
    const history = await b.agent.get(`/api/conversations/${chatId}/messages`);
    expect(history.body.messages[0].body).toBe("Hello 🌙 سلام");
    expect(
      (await c.agent.get(`/api/conversations/${chatId}/messages`)).status,
    ).toBe(404);
    expect(
      (
        await c.agent
          .post(`/api/conversations/${chatId}/messages`)
          .set("Origin", origin)
          .send({ body: "intrusion", clientId: randomUUID() })
      ).status,
    ).toBe(404);
    expect(
      (
        await a.agent
          .post(`/api/conversations/${chatId}/messages`)
          .set("Origin", origin)
          .send({ body: "spoof", clientId: randomUUID(), senderId: b.id })
      ).status,
    ).toBe(400);
  });
  it("idempotently retries and rejects reuse for different content", async () => {
    const cid = randomUUID();
    const first = await send(a, "retry safe", cid),
      second = await send(a, "retry safe", cid);
    expect(first.body.id).toBe(second.body.id);
    expect(await db.message.count({ where: { conversationId: chatId } })).toBe(
      1,
    );
    expect((await send(a, "different", cid)).status).toBe(409);
  });
  it("supports replies and sender-only edits, delete-me/everyone, reactions", async () => {
    const first = await send(a, "original");
    const reply = await b.agent
      .post(`/api/conversations/${chatId}/messages`)
      .set("Origin", origin)
      .send({
        body: "reply",
        clientId: randomUUID(),
        replyToId: first.body.id,
      });
    expect(reply.body.replyTo.id).toBe(first.body.id);
    expect(
      (
        await b.agent
          .patch("/api/messages/" + first.body.id)
          .set("Origin", origin)
          .send({ body: "stolen" })
      ).status,
    ).toBe(404);
    expect(
      (
        await a.agent
          .patch("/api/messages/" + first.body.id)
          .set("Origin", origin)
          .send({ body: "edited" })
      ).body.body,
    ).toBe("edited");
    expect(
      (
        await b.agent
          .post("/api/messages/" + first.body.id + "/reactions")
          .set("Origin", origin)
          .send({ emoji: "❤️" })
      ).status,
    ).toBe(204);
    expect(await db.reaction.count()).toBe(1);
    await a.agent
      .delete("/api/messages/" + first.body.id + "?scope=me")
      .set("Origin", origin);
    expect(
      (await a.agent.get(`/api/conversations/${chatId}/messages`)).body
        .messages,
    ).toHaveLength(1);
    expect(
      (await b.agent.get(`/api/conversations/${chatId}/messages`)).body
        .messages,
    ).toHaveLength(2);
    expect(
      (
        await b.agent
          .delete("/api/messages/" + first.body.id + "?scope=everyone")
          .set("Origin", origin)
      ).status,
    ).toBe(403);
    await a.agent
      .delete("/api/messages/" + first.body.id + "?scope=everyone")
      .set("Origin", origin);
    expect(
      (await db.message.findUniqueOrThrow({ where: { id: first.body.id } }))
        .body,
    ).toBe("");
  });
  it("paginates with tied timestamps without gaps or duplicates and no history truncation", async () => {
    const time = new Date();
    await db.message.createMany({
      data: Array.from({ length: 125 }, (_, i) => ({
        conversationId: chatId,
        senderId: a.id,
        body: "message " + i,
        clientId: randomUUID(),
        createdAt: time,
      })),
    });
    const ids: string[] = [];
    let cursor: string | null = null;
    do {
      const result = await b.agent.get(
        `/api/conversations/${chatId}/messages` +
          (cursor ? "?cursor=" + cursor : ""),
      );
      expect(result.status).toBe(200);
      ids.push(...result.body.messages.map((m: { id: string }) => m.id));
      cursor = result.body.nextCursor;
    } while (cursor);
    expect(ids).toHaveLength(125);
    expect(new Set(ids).size).toBe(125);
  });
  it("continues sending across transient windows with no cumulative quota", async () => {
    for (let batch = 0; batch < 3; batch++) {
      for (let i = 0; i < 25; i++)
        expect((await send(a, "continuous " + batch + ":" + i)).status).toBe(
          201,
        );
      const keys = await redis.keys("ns:rate:*");
      if (keys.length) await redis.del(...keys);
    }
    expect(await db.message.count({ where: { conversationId: chatId } })).toBe(
      75,
    );
  });
  it("preserves server-readable markup as text and handles injection safely", async () => {
    const body = "<img src=x onerror=alert(1)> مرحبا";
    expect((await send(a, body)).status).toBe(201);
    const result = await b.agent.get(
      `/api/conversations/${chatId}/messages?search=${encodeURIComponent("' OR 1=1 --")}`,
    );
    expect(result.body.messages).toHaveLength(0);
    expect(await db.user.count()).toBe(3);
  });
  it("updates unread watermarks, personal folders and theme isolation", async () => {
    await send(a);
    let chats = await b.agent.get("/api/conversations");
    expect(chats.body[0].unread).toBe(1);
    await b.agent
      .post(`/api/conversations/${chatId}/read`)
      .set("Origin", origin);
    chats = await b.agent.get("/api/conversations");
    expect(chats.body[0].unread).toBe(0);
    await b.agent
      .patch("/api/conversations/" + chatId)
      .set("Origin", origin)
      .send({ pinned: true, folder: "Friends" });
    expect((await b.agent.get("/api/conversations")).body[0].pinned).toBe(true);
    expect((await a.agent.get("/api/conversations")).body[0].pinned).toBe(
      false,
    );
    await a.agent
      .patch("/api/me")
      .set("Origin", origin)
      .send({ theme: "Ocean Blue" });
    expect((await a.agent.get("/api/me")).body.theme).toBe("Ocean Blue");
    expect((await b.agent.get("/api/me")).body.theme).toBe("Luxury Cream");
  });
  it("blocks messages in both directions and limits group management to admins", async () => {
    await b.agent
      .post("/api/blocks")
      .set("Origin", origin)
      .send({ userId: a.id });
    expect((await send(a)).status).toBe(403);
    expect((await send(b)).status).toBe(403);
    await b.agent.delete("/api/blocks/" + a.id).set("Origin", origin);
    const group = await a.agent
      .post("/api/conversations")
      .set("Origin", origin)
      .send({ kind: "GROUP", title: "Our room", userIds: [b.id] });
    expect(group.status).toBe(201);
    expect(
      (
        await b.agent
          .post("/api/conversations/" + group.body.id + "/members")
          .set("Origin", origin)
          .send({ userId: c.id })
      ).status,
    ).toBe(403);
    expect(
      (
        await a.agent
          .post("/api/conversations/" + group.body.id + "/members")
          .set("Origin", origin)
          .send({ userId: c.id })
      ).status,
    ).toBe(204);
  });
  it("provides private saved messages and deduplicates direct chats", async () => {
    const direct = await b.agent
      .post("/api/conversations")
      .set("Origin", origin)
      .send({ userIds: [a.id] });
    expect(direct.body.id).toBe(chatId);
    const saved = await a.agent
      .post("/api/conversations")
      .set("Origin", origin)
      .send({ kind: "SAVED", userIds: [] });
    expect(saved.status).toBe(201);
    expect(
      (await b.agent.get("/api/conversations/" + saved.body.id + "/messages"))
        .status,
    ).toBe(404);
  });
});
describe("media and administration", () => {
  it("validates file signatures and protects private download and size", async () => {
    const prefix = `/api/conversations/${chatId}/attachments`;
    expect(
      (
        await c.agent
          .post(prefix)
          .set("Origin", origin)
          .attach("file", Buffer.from("%PDF-1.7"), "a.pdf")
      ).status,
    ).toBe(404);
    expect(
      (
        await a.agent
          .post(prefix)
          .set("Origin", origin)
          .attach("file", Buffer.from("<script>bad</script>"), {
            filename: "x.png",
            contentType: "image/png",
          })
      ).status,
    ).toBe(400);
    const valid = await a.agent
      .post(prefix)
      .set("Origin", origin)
      .attach("file", Buffer.from("%PDF-1.7\nMinimal test fixture"), {
        filename: "../test.pdf",
        contentType: "application/pdf",
      });
    expect(valid.status).toBe(201);
    expect(valid.body.diskKey).toBeUndefined();
    const download = await b.agent.get("/api/attachments/" + valid.body.id);
    expect(download.status).toBe(200);
    expect(download.headers["content-disposition"]).toContain("attachment;");
    expect(
      (await c.agent.get("/api/attachments/" + valid.body.id)).status,
    ).toBe(404);
    const big = Buffer.alloc(config.MAX_UPLOAD_MB * 1024 * 1024 + 1);
    expect(
      (
        await a.agent.post(prefix).set("Origin", origin).attach("file", big, {
          filename: "large.pdf",
          contentType: "application/pdf",
        })
      ).status,
    ).toBe(413);
  });
  it("enforces admin RBAC and safe metric audit", async () => {
    expect((await a.agent.get("/api/admin/metrics")).status).toBe(403);
    await db.user.update({ where: { id: a.id }, data: { role: "ADMIN" } });
    const metrics = await a.agent.get("/api/admin/metrics");
    expect(metrics.status).toBe(200);
    expect(metrics.body.users).toBe(3);
    expect(JSON.stringify(metrics.body)).not.toContain("passwordHash");
    expect(
      await db.securityEvent.count({
        where: { action: "ADMIN_METRICS_VIEWED" },
      }),
    ).toBe(1);
  });
  it("health/readiness and honest capabilities", async () => {
    expect((await request(app).get("/api/health")).status).toBe(200);
    expect((await request(app).get("/api/ready")).body.redis).toBe("ok");
    expect((await request(app).get("/api/capabilities")).body.e2ee).toBe(false);
  });
});
describe("realtime session security and synchronization", () => {
  it("rejects unauthenticated WebSocket connections", async () => {
    await expect(connect("")).rejects.toThrow();
  });
  it("broadcasts persisted messages only to authorized members and syncs after reconnect", async () => {
    const sa = await connect(a.cookie),
      sb = await connect(b.cookie),
      sc = await connect(c.cookie);
    try {
      const received = new Promise<{ body: string }>((resolve) =>
        sb.once("message.new", resolve),
      );
      let leaked = false;
      sc.on("message.new", () => {
        leaked = true;
      });
      const sent = await send(a, "real-time payload");
      expect((await received).body).toBe("real-time payload");
      const receipt = new Promise<void>((resolve) =>
        sa.once("messages.updated", () => resolve()),
      );
      sb.emit("message.received", { messageId: sent.body.id });
      await receipt;
      expect(await db.receipt.count()).toBe(1);
      await new Promise((resolve) => setTimeout(resolve, 100));
      expect(leaked).toBe(false);
      sb.disconnect();
      await send(a, "while offline");
      expect(
        (await b.agent.get(`/api/conversations/${chatId}/messages`)).body
          .messages,
      ).toHaveLength(2);
      const reconnect = await connect(b.cookie);
      reconnect.disconnect();
    } finally {
      sa.disconnect();
      sb.disconnect();
      sc.disconnect();
    }
  });
  it("disconnects a socket after session revocation", async () => {
    const socket = await connect(a.cookie);
    try {
      const disconnected = new Promise<void>((resolve) =>
        socket.once("disconnect", () => resolve()),
      );
      const sessions = await a.agent.get("/api/sessions");
      await a.agent
        .delete("/api/sessions/" + sessions.body[0].id)
        .set("Origin", origin);
      await disconnected;
      expect(socket.connected).toBe(false);
    } finally {
      socket.disconnect();
    }
  });
});
describe("defense-in-depth regressions", () => {
  it("cannot revoke another account session or disconnect that device", async () => {
    const socket = await connect(b.cookie);
    try {
      const sessions = await b.agent.get("/api/sessions");
      await a.agent
        .delete("/api/sessions/" + sessions.body[0].id)
        .set("Origin", origin);
      expect((await b.agent.get("/api/me")).status).toBe(200);
      expect(socket.connected).toBe(true);
    } finally {
      socket.disconnect();
    }
  });
  it("fails closed instead of silently sending when E2EE is required", async () => {
    config.REQUIRE_E2EE = true;
    try {
      expect((await send(a)).status).toBe(503);
      expect(
        (
          await a.agent
            .post("/api/conversations/" + chatId + "/attachments")
            .set("Origin", origin)
        ).status,
      ).toBe(503);
      expect(
        await db.message.count({ where: { conversationId: chatId } }),
      ).toBe(0);
    } finally {
      config.REQUIRE_E2EE = false;
    }
  });
});
describe("configured CAPTCHA provider integration", () => {
  it("requires backend-verified token, validates action/host and prevents replay", async () => {
    const old = {
      required: config.CAPTCHA_REQUIRED,
      secret: config.TURNSTILE_SECRET,
    };
    config.CAPTCHA_REQUIRED = true;
    config.TURNSTILE_SECRET = "test-only-secret";
    const fetchMock = vi.spyOn(globalThis, "fetch").mockImplementation(
      async () =>
        new Response(
          JSON.stringify({
            success: true,
            hostname: config.TURNSTILE_HOSTNAME,
            action: "login",
          }),
          { status: 200 },
        ),
    );
    try {
      const input = { username: a.username, password: pass };
      expect(
        (
          await request(app)
            .post("/api/auth/login")
            .set("Origin", origin)
            .send(input)
        ).status,
      ).toBe(400);
      expect(
        (
          await request(app)
            .post("/api/auth/login")
            .set("Origin", origin)
            .send({ ...input, captchaToken: "test-once" })
        ).status,
      ).toBe(200);
      expect(
        (
          await request(app)
            .post("/api/auth/login")
            .set("Origin", origin)
            .send({ ...input, captchaToken: "test-once" })
        ).status,
      ).toBe(400);
      fetchMock.mockResolvedValue(
        new Response(
          JSON.stringify({
            success: true,
            hostname: "evil.example",
            action: "login",
          }),
          { status: 200 },
        ),
      );
      expect(
        (
          await request(app)
            .post("/api/auth/login")
            .set("Origin", origin)
            .send({ ...input, captchaToken: "different" })
        ).status,
      ).toBe(400);
    } finally {
      config.CAPTCHA_REQUIRED = old.required;
      config.TURNSTILE_SECRET = old.secret;
      fetchMock.mockRestore();
    }
  });
});
