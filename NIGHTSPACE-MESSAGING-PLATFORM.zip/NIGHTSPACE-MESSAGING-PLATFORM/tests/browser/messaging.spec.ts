import { test, expect, type Page } from "@playwright/test";
import { themeNames } from "@nightspace/shared";
import { Redis } from "ioredis";
const password = "browser-tests-long-passphrase";
test.beforeEach(async () => {
  if (
    process.env.NIGHTSPACE_TEST_ALLOW_RESET !== "true" ||
    !process.env.REDIS_URL?.endsWith("/15") ||
    !new URL(process.env.DATABASE_URL || "http://invalid").pathname.endsWith(
      "_test",
    )
  )
    throw new Error(
      "Browser tests require explicit test reset guard, *_test DB and Redis DB 15",
    );
  const redis = new Redis(process.env.REDIS_URL);
  await redis.flushdb();
  await redis.quit();
});
async function register(page: Page, name: string) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Create an account", exact: true })
    .click();
  await page.getByLabel("Display name", { exact: true }).fill(name);
  await page.getByLabel("Username", { exact: true }).fill(name);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page
    .getByRole("button", { name: "Create your space", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: "Messages." })).toBeVisible();
}
test("real two-user messaging, Unicode, literal XSS, reply, persistence and reconnect", async ({
  browser,
}) => {
  const ca = await browser.newContext(),
    cb = await browser.newContext();
  const a = await ca.newPage(),
    b = await cb.newPage();
  const suffix = Date.now().toString(36),
    an = "a_" + suffix,
    bn = "b_" + suffix;
  try {
    await register(a, an);
    await register(b, bn);
    await expect(a.getByTitle("Realtime connected")).toBeVisible();
    await expect(b.getByTitle("Realtime connected")).toBeVisible();
    await a
      .getByRole("button", { name: "New conversation", exact: true })
      .click();
    await a.getByLabel("Exact username").fill(bn);
    await a
      .getByRole("button", { name: "Start a conversation", exact: true })
      .last()
      .click();
    await expect(a.getByLabel("Write a message")).toBeVisible();
    const content = "سلام 🌙 hello مرحبا <img src=x onerror=alert(1)>";
    await a.getByLabel("Write a message").fill(content);
    await a.getByLabel("Send message", { exact: true }).click();
    await expect(
      a.getByRole("log").getByText(content, { exact: true }),
    ).toBeVisible();
    await expect(
      b.getByRole("button").filter({ hasText: an }).first(),
    ).toBeVisible();
    await b.getByRole("button").filter({ hasText: an }).first().click();
    await expect(
      b.getByRole("log").getByText(content, { exact: true }),
    ).toBeVisible();
    expect(await b.locator(".bubble img").count()).toBe(0);
    await b.locator(".message-options summary").first().click();
    await b.getByRole("button", { name: "Reply", exact: true }).click();
    await b.getByLabel("Write a message").fill("A reply across two browsers");
    await b.getByLabel("Send message", { exact: true }).click();
    await expect(
      a
        .getByRole("log")
        .getByText("A reply across two browsers", { exact: true }),
    ).toBeVisible();
    await a.reload();
    await a.getByRole("button").filter({ hasText: bn }).first().click();
    await expect(
      a
        .getByRole("log")
        .getByText("A reply across two browsers", { exact: true }),
    ).toBeVisible();
    await ca.setOffline(true);
    await b.getByLabel("Write a message").fill("Sent while you were offline");
    await b.getByLabel("Send message", { exact: true }).click();
    await ca.setOffline(false);
    await expect(
      a
        .getByRole("log")
        .getByText("Sent while you were offline", { exact: true }),
    ).toBeVisible();
    await expect(a.getByRole("status")).toHaveCount(0, { timeout: 10000 });
    await a.screenshot({ path: "docs/screenshots/desktop-chat.png" });
  } finally {
    await ca.close();
    await cb.close();
  }
});
test("all 13 themes preview, save, survive reload, and stay per user", async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 1100 });
  await register(page, "theme_" + Date.now().toString(36));
  await page.getByRole("button", { name: "Settings", exact: true }).click();
  for (const name of themeNames) {
    const button = page.getByRole("button", { name, exact: true });
    await button.click();
    await expect(button).toHaveAttribute("aria-pressed", "true");
  }
  await page.getByRole("button", { name: "Ocean Blue", exact: true }).click();
  await page.locator(".modal").evaluate((el) => {
    el.scrollTop = 0;
  });
  await page.screenshot({ path: "docs/screenshots/theme-gallery.png" });
  await page
    .getByRole("button", { name: "Save appearance", exact: true })
    .click();
  await expect(page.getByRole("status")).toContainText("Preferences saved");
  await page.getByLabel("Close dialog").click();
  await page.reload();
  expect(
    await page
      .locator("html")
      .evaluate((el) => getComputedStyle(el).getPropertyValue("--bg").trim()),
  ).toBe("#0d2334");
});
test("mobile separate chat screen, safe layout, keyboard composer and privacy settings", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await register(page, "mobile_" + Date.now().toString(36));
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page
    .getByRole("button", { name: "Saved messages", exact: true })
    .click();
  await expect(page.getByLabel("Write a message")).toBeVisible();
  await page.getByLabel("Write a message").fill("یادداشت شخصی ✨");
  await page.getByLabel("Write a message").press("Enter");
  await expect(
    page.getByRole("log").getByText("یادداشت شخصی ✨", { exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await expect(page.locator(".messages article .bubble")).toContainText(
    "یادداشت شخصی ✨",
  );
  await expect(page.locator(".messages article").last()).toHaveCSS(
    "opacity",
    "1",
  );
  await page.screenshot({ path: "docs/screenshots/mobile-chat.png" });
  await page.getByLabel("Back to conversations").click();
  await page.getByRole("button", { name: "Settings", exact: true }).click();
  await page.getByRole("button", { name: "Security", exact: true }).click();
  await expect(
    page.getByText(
      "Messages and uploaded files are NOT end-to-end encrypted.",
      { exact: false },
    ),
  ).toBeVisible();
  await page.getByLabel("Share typing status").uncheck();
  await expect(page.getByRole("status")).toContainText("Preferences saved");
});
