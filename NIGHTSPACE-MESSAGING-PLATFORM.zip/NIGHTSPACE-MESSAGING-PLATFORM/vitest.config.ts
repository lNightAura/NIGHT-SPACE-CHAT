import { defineConfig } from "vitest/config";
import { config } from "dotenv";
config({ quiet: true });
process.env.NODE_ENV = "test";
// Unit tests do not contact these defaults. Integration requires explicit reset guard.
process.env.DATABASE_URL ||=
  "postgresql://unused:unused@localhost:5432/unused_test";
process.env.REDIS_URL ||= "redis://localhost:6379/15";
export default defineConfig({
  test: {
    fileParallelism: false,
    testTimeout: 20000,
    hookTimeout: 30000,
    reporters: ["default"],
    include: ["tests/*.test.ts"],
  },
});
