import { Nightspace } from "../components/Nightspace";
export default function Page() {
  return <Nightspace />;
}
