import Link from "next/link";
export default function NotFound() {
  return (
    <main className="empty">
      <span className="eyebrow">NIGHTSPACE / 404</span>
      <h1>A little off course.</h1>
      <p>This space doesn't exist.</p>
      <Link href="/">Back to your conversations →</Link>
    </main>
  );
}
