import type { Metadata } from "next";
import { cookies } from "next/headers";
import { themeNames, themes, type ThemeName } from "@nightspace/shared";
import type { CSSProperties } from "react";
import "./globals.css";
export const metadata: Metadata = {
  title: "NIGHTSPACE — A little closer.",
  description: "An intentional space for your conversations.",
};
export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const jar = await cookies();
  const saved = jar.get("ns-theme")?.value;
  const theme: ThemeName =
    themeNames.find(
      (name) => name === saved || encodeURIComponent(name) === saved,
    ) || "Luxury Cream";
  const accent = jar.get("ns-accent")?.value;
  const vars = {
    ...themes[theme],
    ...(accent && /^[a-f0-9]{6}$/i.test(accent)
      ? { "--accent": "#" + accent }
      : {}),
  };
  return (
    <html lang="en" style={vars as CSSProperties}>
      <body>{children}</body>
    </html>
  );
}
