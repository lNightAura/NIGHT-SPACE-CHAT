"use client";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main className="empty">
      <h1>Something went quiet.</h1>
      <p>
        We couldn't load this space. Your stored conversations are still on the
        server.
      </p>
      <button onClick={reset}>Try again</button>
    </main>
  );
}
