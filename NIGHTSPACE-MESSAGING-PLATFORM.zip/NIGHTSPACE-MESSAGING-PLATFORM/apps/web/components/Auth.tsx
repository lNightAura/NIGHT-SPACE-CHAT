"use client";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowUpRight, ShieldCheck, MessageCircle, Globe2 } from "lucide-react";
import type { Account } from "@nightspace/shared";
import { api, errorMessage, type Capabilities } from "./api";
import { Brand } from "./primitives";
type Turnstile = {
  render: (el: HTMLElement, options: Record<string, unknown>) => string;
  remove: (id: string) => void;
  reset: (id: string) => void;
};
declare global {
  interface Window {
    turnstile?: Turnstile;
  }
}
export function Auth({
  onLogin,
  capabilities,
}: {
  onLogin: (u: Account) => void;
  capabilities: Capabilities | null;
}) {
  const [register, setRegister] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [token, setToken] = useState("");
  const captchaRef = useRef<HTMLDivElement>(null),
    widget = useRef<string | null>(null);
  useEffect(() => {
    if (!capabilities?.captchaRequired) return;
    const start = () => {
      if (captchaRef.current && window.turnstile) {
        widget.current = window.turnstile.render(captchaRef.current, {
          sitekey: capabilities.captchaSiteKey,
          action: register ? "register" : "login",
          callback: (v: string) => setToken(v),
          "expired-callback": () => setToken(""),
          "error-callback": () =>
            setError("Security challenge unavailable. Retry later."),
        });
      }
    };
    let script = document.querySelector<HTMLScriptElement>("#turnstile-script");
    if (!script) {
      script = document.createElement("script");
      script.id = "turnstile-script";
      script.src =
        "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
      script.async = true;
      document.head.appendChild(script);
    }
    if (window.turnstile) start();
    else script.addEventListener("load", start);
    return () => {
      script?.removeEventListener("load", start);
      if (widget.current) window.turnstile?.remove(widget.current);
      widget.current = null;
      setToken("");
    };
  }, [capabilities, register]);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const data = new FormData(e.currentTarget);
    try {
      onLogin(
        await api<Account>(
          register ? "/auth/register" : "/auth/login",
          "POST",
          {
            username: data.get("username"),
            password: data.get("password"),
            ...(register ? { displayName: data.get("displayName") } : {}),
            ...(token ? { captchaToken: token } : {}),
          },
        ),
      );
    } catch (e) {
      setError(errorMessage(e));
      if (widget.current) window.turnstile?.reset(widget.current);
      setToken("");
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="auth-page">
      <section className="auth-story">
        <Brand />
        <div>
          <span className="eyebrow">LESS NOISE. MORE CONNECTION.</span>
          <h1>
            Good conversations
            <br />
            deserve their
            <br />
            <em>own space.</em>
          </h1>
          <p>
            For the everyday hellos. The big ideas.
            <br />
            And everything that brings you closer.
          </p>
          <div className="orbit-art" aria-hidden="true">
            <div />
            <div />
            <div />
            <span>n.</span>
          </div>
        </div>
        <footer>
          <span>
            <MessageCircle size={16} /> No message subscriptions
          </span>
          <span>
            <Globe2 size={16} /> Every language welcome
          </span>
        </footer>
      </section>
      <section className="auth-form">
        <div className="auth-card">
          <span className="eyebrow">YOUR SPACE IS WAITING</span>
          <h2>{register ? "Make yourself at home." : "Welcome back."}</h2>
          <p>
            {register
              ? "A new chapter starts with a hello."
              : "Pick up right where you left off."}
          </p>
          <form onSubmit={submit}>
            {register && (
              <label>
                Display name
                <input
                  name="displayName"
                  autoComplete="name"
                  maxLength={80}
                  required
                />
              </label>
            )}
            <label>
              Username
              <input
                name="username"
                autoComplete="username"
                pattern="[A-Za-z0-9_]{3,32}"
                minLength={3}
                maxLength={32}
                placeholder="your_username"
                required
              />
            </label>
            <label>
              Password
              <input
                name="password"
                type="password"
                autoComplete={register ? "new-password" : "current-password"}
                minLength={register ? 12 : 1}
                maxLength={128}
                placeholder={
                  register ? "At least 12 characters" : "Enter your password"
                }
                required
              />
            </label>
            <div ref={captchaRef} />
            {error && (
              <p role="alert" className="error">
                {error}
              </p>
            )}
            <button
              className="primary"
              disabled={
                busy ||
                !capabilities ||
                (capabilities.captchaRequired && !token)
              }
            >
              {busy
                ? "One moment…"
                : register
                  ? "Create your space"
                  : "Enter your space"}
              <ArrowUpRight size={18} />
            </button>
          </form>
          <p className="switch">
            {register
              ? "Already part of the conversation?"
              : "New around here?"}{" "}
            <button
              onClick={() => {
                setRegister(!register);
                setError("");
              }}
            >
              {register ? "Sign in" : "Create an account"}
            </button>
          </p>
          <div className="privacy-note">
            <ShieldCheck size={19} />
            <span>
              Development milestone. Messages are server-readable.
              <br />
              <strong>End-to-end encryption is not available.</strong>
            </span>
          </div>
        </div>
      </section>
    </main>
  );
}
