"use client";
import { useEffect, useState, type CSSProperties, type FormEvent } from "react";
import {
  Check,
  LogOut,
  Palette,
  Shield,
  UserRound,
  Download,
  Trash2,
} from "lucide-react";
import {
  themes,
  themeNames,
  contrast,
  type ThemeName,
  type Account,
} from "@nightspace/shared";
import { api, errorMessage } from "./api";
import { Modal, Avatar } from "./primitives";
type Session = {
  id: string;
  createdAt: string;
  expiresAt: string;
  current: boolean;
};
export function applyTheme(name: ThemeName, accent?: string | null) {
  const vars = { ...themes[name], ...(accent ? { "--accent": accent } : {}) };
  for (const [key, val] of Object.entries(vars))
    document.documentElement.style.setProperty(key, val);
  document.cookie = `ns-theme=${encodeURIComponent(name)}; Path=/; SameSite=Lax; Max-Age=31536000`;
  document.cookie = `ns-accent=${accent?.slice(1) || ""}; Path=/; SameSite=Lax; Max-Age=${accent ? 31536000 : 0}`;
}
export function Settings({
  user,
  onUser,
  close,
  onLogout,
  toast,
}: {
  user: Account;
  onUser: (u: Account) => void;
  close: () => void;
  onLogout: () => void;
  toast: (s: string) => void;
}) {
  const [tab, setTab] = useState("Appearance"),
    [preview, setPreview] = useState(user.theme),
    [accent, setAccent] = useState(
      user.accent || themes[user.theme]["--accent"],
    ),
    [sessions, setSessions] = useState<Session[]>([]),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  useEffect(() => {
    api<Session[]>("/sessions")
      .then(setSessions)
      .catch((e) => setError(errorMessage(e)));
    return () => applyTheme(user.theme, user.accent);
  }, [user.theme, user.accent]);
  async function save(data: unknown) {
    setBusy(true);
    setError("");
    try {
      const updated = await api<Account>("/me", "PATCH", data);
      onUser(updated);
      applyTheme(updated.theme, updated.accent);
      toast("Preferences saved across your devices.");
    } catch (e) {
      onUser(user);
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  async function profile(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const d = new FormData(e.currentTarget);
    await save({ displayName: d.get("displayName"), bio: d.get("bio") });
  }
  async function changePassword(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget,
      d = new FormData(form);
    setBusy(true);
    try {
      await api("/me/password", "POST", {
        currentPassword: d.get("currentPassword"),
        newPassword: d.get("newPassword"),
      });
      toast("Password changed. Other sessions revoked.");
      form.reset();
      setSessions(await api("/sessions"));
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title="Make it yours" close={close} wide>
      <div className="settings-tabs">
        {[
          ["Appearance", Palette],
          ["Profile", UserRound],
          ["Security", Shield],
        ].map(([name, Icon]) => (
          <button
            className={tab === name ? "active" : ""}
            key={String(name)}
            onClick={() => setTab(String(name))}
          >
            {typeof Icon !== "string" && <Icon size={16} />} {String(name)}
          </button>
        ))}
      </div>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {tab === "Appearance" && (
        <>
          <div className="section-heading">
            <div>
              <h3>A mood for every moment.</h3>
              <p>13 considered palettes. One personal space.</p>
            </div>
            <button
              onClick={() => {
                setPreview("Luxury Cream");
                setAccent(themes["Luxury Cream"]["--accent"]);
                applyTheme("Luxury Cream");
              }}
            >
              Reset
            </button>
          </div>
          <div className="theme-grid">
            {themeNames.map((name) => (
              <button
                key={name}
                aria-pressed={preview === name}
                className={"theme-card " + (preview === name ? "selected" : "")}
                onClick={() => {
                  setPreview(name);
                  setAccent(themes[name]["--accent"]);
                  applyTheme(name);
                }}
              >
                <div
                  className="theme-sample"
                  style={themes[name] as CSSProperties}
                >
                  <i />
                  <span />
                  <span />
                  {preview === name && <Check size={17} />}
                </div>
                <strong>{name}</strong>
              </button>
            ))}
          </div>
          <label className="color-label">
            Personal accent{" "}
            <input
              aria-label="Accent color"
              type="color"
              value={accent}
              onChange={(e) => {
                setAccent(e.target.value);
                applyTheme(preview, e.target.value);
              }}
            />
          </label>
          {contrast(accent, themes[preview]["--panel"]) < 3 && (
            <p className="error">
              Choose an accent with at least 3:1 contrast against the panel.
            </p>
          )}
          <button
            className="primary"
            disabled={busy || contrast(accent, themes[preview]["--panel"]) < 3}
            onClick={() => save({ theme: preview, accent })}
          >
            Save appearance <Check size={17} />
          </button>
          <p className="fine">
            Preview is temporary until saved. Accent contrast is checked; full
            WCAG audit is pending.
          </p>
        </>
      )}
      {tab === "Profile" && (
        <form onSubmit={profile}>
          <div className="profile-head">
            <Avatar name={user.displayName} />
            <div>
              <h3>{user.displayName}</h3>
              <p>@{user.username}</p>
            </div>
          </div>
          <label>
            Display name
            <input
              name="displayName"
              defaultValue={user.displayName}
              required
              maxLength={80}
            />
          </label>
          <label>
            A little about you
            <textarea
              name="bio"
              defaultValue={user.bio}
              maxLength={240}
              rows={3}
            />
          </label>
          <button className="primary" disabled={busy}>
            Save profile
          </button>
        </form>
      )}
      {tab === "Security" && (
        <div className="security-settings">
          <div className="privacy-note">
            <Shield size={20} />
            <span>
              Transport should use HTTPS in production.{" "}
              <strong>
                Messages and uploaded files are NOT end-to-end encrypted.
              </strong>{" "}
              Do not use this milestone for sensitive communications.
            </span>
          </div>
          <h3>Privacy preferences</h3>
          <label className="toggle">
            Share read receipts
            <input
              type="checkbox"
              checked={user.readReceipts}
              onChange={(e) => {
                onUser({ ...user, readReceipts: e.target.checked });
                save({ readReceipts: e.target.checked });
              }}
            />
          </label>
          <label className="toggle">
            Share typing status
            <input
              type="checkbox"
              checked={user.typingVisible}
              onChange={(e) => {
                onUser({ ...user, typingVisible: e.target.checked });
                save({ typingVisible: e.target.checked });
              }}
            />
          </label>
          <h3>Active sessions</h3>
          {sessions.map((s) => (
            <div className="session" key={s.id}>
              <span>
                {s.current ? "This session" : "Another session"}
                <small>
                  Created {new Date(s.createdAt).toLocaleString()} · expires{" "}
                  {new Date(s.expiresAt).toLocaleDateString()}
                </small>
              </span>
              <button
                onClick={async () => {
                  try {
                    await api("/sessions/" + s.id, "DELETE");
                    if (s.current) onLogout();
                    else setSessions(sessions.filter((x) => x.id !== s.id));
                  } catch (e) {
                    setError(errorMessage(e));
                  }
                }}
              >
                Revoke
              </button>
            </div>
          ))}
          <form onSubmit={changePassword}>
            <h3>Change password</h3>
            <label>
              Current password
              <input
                name="currentPassword"
                type="password"
                autoComplete="current-password"
                maxLength={128}
                required
              />
            </label>
            <label>
              New password
              <input
                name="newPassword"
                type="password"
                minLength={12}
                maxLength={128}
                autoComplete="new-password"
                required
              />
            </label>
            <button disabled={busy}>Update password & revoke sessions</button>
          </form>
          <div className="settings-actions">
            <a className="button" href="/api/me/export" download>
              <Download size={16} /> Export account JSON
            </a>
            <button
              onClick={async () => {
                try {
                  await api("/auth/logout-all", "POST");
                  onLogout();
                } catch (e) {
                  setError(errorMessage(e));
                }
              }}
            >
              <LogOut size={16} /> Sign out all devices
            </button>
            <button
              className="danger"
              onClick={async () => {
                if (
                  !confirm(
                    "Permanently delete your account? This cannot be undone.",
                  )
                )
                  return;
                const password = prompt(
                  "Confirm your current password to delete your account.",
                );
                if (password === null) return;
                try {
                  await api("/me", "DELETE", { password });
                  onLogout();
                } catch (e) {
                  setError(errorMessage(e));
                }
              }}
            >
              <Trash2 size={16} /> Delete account
            </button>
          </div>
          <p className="fine">
            Recovery, two-factor authentication and device encryption
            verification are not available yet.
          </p>
        </div>
      )}
    </Modal>
  );
}
