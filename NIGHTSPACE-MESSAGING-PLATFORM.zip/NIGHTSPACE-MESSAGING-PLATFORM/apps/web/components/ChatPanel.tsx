"use client";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
} from "react";
import type { Socket } from "socket.io-client";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowUp,
  Paperclip,
  Smile,
  Search,
  MoreHorizontal,
  Check,
  CheckCheck,
  Reply,
  X,
  FileText,
  Pin,
  Archive,
  BellOff,
  ShieldAlert,
} from "lucide-react";
import type { Account, Chat, ChatMessage } from "@nightspace/shared";
import { api, errorMessage } from "./api";
import { Avatar } from "./primitives";
type Pending = {
  clientId: string;
  body: string;
  replyToId?: string;
  attachmentId?: string;
  failed: boolean;
};
export const chatTitle = (chat: Chat, user: Account) =>
  chat.title ||
  (chat.kind === "SAVED"
    ? "Saved Messages"
    : chat.members.find((m) => m.userId !== user.id)?.user.displayName ||
      "Your conversation");
export function ChatPanel({
  chat,
  user,
  socket,
  back,
  refresh,
  toast,
  typing,
  uploads,
}: {
  chat: Chat;
  user: Account;
  socket: Socket | null;
  back: () => void;
  refresh: () => Promise<void>;
  toast: (s: string) => void;
  typing: boolean;
  uploads: boolean;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]),
    [cursor, setCursor] = useState<string | null>(null),
    [draft, setDraft] = useState(""),
    [pending, setPending] = useState<Pending[]>([]),
    [reply, setReply] = useState<ChatMessage | null>(null),
    [attachment, setAttachment] = useState<{
      id: string;
      filename: string;
    } | null>(null),
    [upload, setUpload] = useState<number | null>(null),
    [emoji, setEmoji] = useState(false),
    [search, setSearch] = useState(""),
    [searchOpen, setSearchOpen] = useState(false),
    [loading, setLoading] = useState(true),
    [error, setError] = useState("");
  const end = useRef<HTMLDivElement>(null),
    file = useRef<HTMLInputElement>(null),
    typingLast = useRef(0),
    mounted = useRef(true);
  const load = useCallback(async () => {
    const result = await api<{
      messages: ChatMessage[];
      nextCursor: string | null;
    }>(
      `/conversations/${chat.id}/messages${search ? "?search=" + encodeURIComponent(search) : ""}`,
    );
    if (!mounted.current) return;
    setMessages(result.messages);
    setCursor(result.nextCursor);
    setLoading(false);
    if (!search) await api(`/conversations/${chat.id}/read`, "POST");
    for (const m of result.messages)
      if (
        m.senderId !== user.id &&
        !m.receipts.some((r) => r.userId === user.id)
      )
        socket?.emit("message.received", { messageId: m.id });
  }, [chat.id, search, socket, user.id]);
  useEffect(() => {
    mounted.current = true;
    setLoading(true);
    setError("");
    load().catch((e) => {
      setError(errorMessage(e));
      setLoading(false);
    });
    return () => {
      mounted.current = false;
    };
  }, [load]);
  useEffect(() => {
    if (!socket) return;
    const update = (data: { conversationId: string }) => {
      if (data.conversationId === chat.id)
        load().catch((e) => setError(errorMessage(e)));
    };
    const connect = () => load().catch((e) => setError(errorMessage(e)));
    const fallback = setInterval(connect, 10000);
    socket.on("message.new", update);
    socket.on("messages.updated", update);
    socket.on("connect", connect);
    return () => {
      clearInterval(fallback);
      socket.off("message.new", update);
      socket.off("messages.updated", update);
      socket.off("connect", connect);
    };
  }, [socket, chat.id, load]);
  useEffect(() => {
    end.current?.scrollIntoView({ behavior: "instant" });
  }, [messages.length, pending.length]);
  async function send(item?: Pending) {
    const p = item || {
      body: draft,
      clientId: crypto.randomUUID(),
      replyToId: reply?.id,
      attachmentId: attachment?.id,
      failed: false,
    };
    if (!p.body.trim() && !p.attachmentId) return;
    if (!item) {
      setDraft("");
      setReply(null);
      setAttachment(null);
      setPending((old) => [...old, p]);
    } else
      setPending((old) =>
        old.map((x) =>
          x.clientId === p.clientId ? { ...x, failed: false } : x,
        ),
      );
    try {
      await api(`/conversations/${chat.id}/messages`, "POST", {
        body: p.body,
        clientId: p.clientId,
        ...(p.replyToId ? { replyToId: p.replyToId } : {}),
        ...(p.attachmentId ? { attachmentId: p.attachmentId } : {}),
      });
      setPending((old) => old.filter((x) => x.clientId !== p.clientId));
      await load();
      await refresh();
    } catch (e) {
      setPending((old) =>
        old.map((x) =>
          x.clientId === p.clientId ? { ...x, failed: true } : x,
        ),
      );
      setError(errorMessage(e));
    }
  }
  async function older() {
    if (!cursor) return;
    try {
      const result = await api<{
        messages: ChatMessage[];
        nextCursor: string | null;
      }>(
        `/conversations/${chat.id}/messages?cursor=${encodeURIComponent(cursor)}${search ? "&search=" + encodeURIComponent(search) : ""}`,
      );
      setMessages((old) => [...result.messages, ...old]);
      setCursor(result.nextCursor);
    } catch (e) {
      setError(errorMessage(e));
    }
  }
  function uploadFile(f: File) {
    if (!uploads) {
      toast("Uploads are disabled for this environment.");
      return;
    }
    setUpload(0);
    const data = new FormData();
    data.append("file", f);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/conversations/${chat.id}/attachments`);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) setUpload(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      setUpload(null);
      try {
        const result = JSON.parse(xhr.responseText);
        if (xhr.status >= 400) throw new Error(result.error);
        setAttachment(result);
      } catch (e) {
        setError(errorMessage(e));
      }
    };
    xhr.onerror = () => {
      setUpload(null);
      setError("Upload failed. Retry your file.");
    };
    xhr.send(data);
  }
  async function action(task: () => Promise<unknown>) {
    try {
      await task();
      await load();
      await refresh();
    } catch (e) {
      setError(errorMessage(e));
    }
  }
  async function setChat(data: unknown) {
    await action(() => api("/conversations/" + chat.id, "PATCH", data));
  }
  const partner = chat.members.find((m) => m.userId !== user.id);
  return (
    <section
      className="chat-panel"
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]);
      }}
    >
      <header className="chat-header">
        <button
          className="icon mobile-back"
          aria-label="Back to conversations"
          onClick={back}
        >
          <ArrowLeft size={21} />
        </button>
        <Avatar name={chatTitle(chat, user)} />
        <div className="chat-identity">
          <h2>{chatTitle(chat, user)}</h2>
          <span>
            {typing
              ? "typing…"
              : chat.kind === "GROUP"
                ? `${chat.members.length} members`
                : chat.kind === "SAVED"
                  ? "A little space for yourself"
                  : partner
                    ? "@" + partner.user.username
                    : "Private conversation"}
          </span>
        </div>
        <button
          className="icon"
          aria-label="Search messages"
          onClick={() => setSearchOpen(!searchOpen)}
        >
          <Search size={19} />
        </button>
        <details className="dropdown">
          <summary aria-label="Conversation options">
            <MoreHorizontal size={21} />
          </summary>
          <div className="menu">
            <button onClick={() => setChat({ pinned: !chat.pinned })}>
              <Pin size={15} />
              {chat.pinned ? "Unpin" : "Pin"} conversation
            </button>
            <button onClick={() => setChat({ archived: !chat.archived })}>
              <Archive size={15} />
              {chat.archived ? "Unarchive" : "Archive"}
            </button>
            <button onClick={() => setChat({ muted: !chat.muted })}>
              <BellOff size={15} />
              {chat.muted ? "Unmute" : "Mute"}
            </button>
            <button
              onClick={() => {
                const folder = prompt("Folder name", chat.folder);
                if (folder !== null) setChat({ folder });
              }}
            >
              Set folder
            </button>
            {partner && (
              <>
                <button
                  onClick={() => {
                    if (confirm("Block this user?"))
                      action(() =>
                        api("/blocks", "POST", { userId: partner.userId }),
                      );
                  }}
                >
                  Block @{partner.user.username}
                </button>
                <button
                  onClick={() => {
                    const reason = prompt(
                      "Describe the concern (no private message content).",
                    );
                    if (reason)
                      action(() =>
                        api("/reports", "POST", {
                          targetId: partner.userId,
                          reason,
                        }),
                      );
                  }}
                >
                  Report user
                </button>
              </>
            )}
          </div>
        </details>
      </header>
      {searchOpen && (
        <div className="chat-search">
          <Search size={17} />
          <input
            aria-label="Search message history"
            placeholder="Search this conversation"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <button
            className="icon"
            aria-label="Close search"
            onClick={() => {
              setSearch("");
              setSearchOpen(false);
            }}
          >
            <X size={17} />
          </button>
        </div>
      )}
      <div className="transport-notice">
        <ShieldAlert size={12} /> Server-readable development chat · not
        end-to-end encrypted
      </div>
      <div
        className="messages"
        aria-label="Messages"
        role="log"
        aria-live="polite"
      >
        {loading ? (
          <div className="skeletons">
            <i />
            <i />
            <i />
          </div>
        ) : (
          <>
            {cursor && (
              <button className="load-older" onClick={older}>
                Load earlier messages
              </button>
            )}
            {messages.length > 0 && (
              <div className="date-divider">
                <span>
                  {new Date(messages[0].createdAt).toLocaleDateString(
                    undefined,
                    { month: "long", day: "numeric", year: "numeric" },
                  )}
                </span>
              </div>
            )}
            {!messages.length && (
              <div className="conversation-empty">
                <span>Say something lovely.</span>
                <p>This is the beginning of your conversation.</p>
              </div>
            )}
            {messages.map((m) => {
              const own = m.senderId === user.id,
                read = chat.members.some(
                  (mem) =>
                    mem.userId !== user.id &&
                    new Date(mem.lastReadAt) >= new Date(m.createdAt),
                );
              return (
                <motion.article
                  key={m.id}
                  className={"message-row " + (own ? "own" : "")}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  {!own && <Avatar name={m.sender.displayName} small />}
                  <div className="message-stack">
                    {!own && chat.kind === "GROUP" && (
                      <span className="sender-name">
                        {m.sender.displayName}
                      </span>
                    )}
                    <div className="bubble">
                      {m.replyTo && (
                        <blockquote dir="auto">
                          {m.replyTo.body || "Deleted message"}
                        </blockquote>
                      )}
                      {m.deletedAt ? (
                        <p className="deleted">Message deleted</p>
                      ) : (
                        <>
                          <p dir="auto">{m.body}</p>
                          {m.attachment && (
                            <a
                              className="attachment"
                              href={"/api/attachments/" + m.attachment.id}
                              download
                            >
                              <FileText size={21} />
                              <span>
                                {m.attachment.filename}
                                <small>
                                  {Math.ceil(m.attachment.size / 1024)} KB ·
                                  download
                                </small>
                              </span>
                            </a>
                          )}
                        </>
                      )}
                      <div className="message-meta">
                        {m.editedAt && <span>edited</span>}
                        <time dateTime={m.createdAt}>
                          {new Date(m.createdAt).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </time>
                        {own &&
                          (read ? (
                            <CheckCheck size={14} aria-label="Read" />
                          ) : m.receipts.length ? (
                            <CheckCheck size={14} aria-label="Delivered" />
                          ) : (
                            <Check size={14} aria-label="Sent" />
                          ))}
                      </div>
                    </div>
                    {m.reactions.length > 0 && (
                      <div className="reactions">
                        {[...new Set(m.reactions.map((r) => r.emoji))].map(
                          (em) => (
                            <button
                              key={em}
                              onClick={() =>
                                action(() =>
                                  api(
                                    "/messages/" + m.id + "/reactions",
                                    "POST",
                                    { emoji: em },
                                  ),
                                )
                              }
                            >
                              {em}{" "}
                              {m.reactions.filter((r) => r.emoji === em).length}
                            </button>
                          ),
                        )}
                      </div>
                    )}
                  </div>
                  {!m.deletedAt && (
                    <details
                      className="dropdown message-options"
                      onToggle={(e) => {
                        if (e.currentTarget.open) {
                          const rect = e.currentTarget.getBoundingClientRect();
                          e.currentTarget.style.setProperty(
                            "--menu-top",
                            `${Math.max(90, Math.min(rect.bottom + 6, innerHeight - 350))}px`,
                          );
                          e.currentTarget.style.setProperty(
                            "--menu-left",
                            `${Math.max(12, Math.min(rect.right - 200, innerWidth - 212))}px`,
                          );
                        }
                      }}
                    >
                      <summary aria-label="Message actions">
                        <MoreHorizontal size={16} />
                      </summary>
                      <div className="menu">
                        <button onClick={() => setReply(m)}>
                          <Reply size={14} /> Reply
                        </button>
                        <button
                          onClick={() =>
                            action(() => navigator.clipboard.writeText(m.body))
                          }
                        >
                          Copy text
                        </button>
                        <button
                          onClick={() =>
                            action(() =>
                              api("/messages/" + m.id + "/reactions", "POST", {
                                emoji: "❤️",
                              }),
                            )
                          }
                        >
                          React ❤️
                        </button>
                        {own && (
                          <>
                            <button
                              onClick={() => {
                                const body = prompt("Edit message", m.body);
                                if (body)
                                  action(() =>
                                    api("/messages/" + m.id, "PATCH", { body }),
                                  );
                              }}
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => {
                                if (
                                  confirm("Delete this message for everyone?")
                                )
                                  action(() =>
                                    api(
                                      "/messages/" + m.id + "?scope=everyone",
                                      "DELETE",
                                    ),
                                  );
                              }}
                            >
                              Delete for everyone
                            </button>
                          </>
                        )}
                        <button
                          onClick={() =>
                            action(() =>
                              api("/messages/" + m.id + "?scope=me", "DELETE"),
                            )
                          }
                        >
                          Delete for me
                        </button>
                        <button
                          onClick={() =>
                            toast(
                              `Message ${m.id} · ${new Date(m.createdAt).toLocaleString()} · ${m.receipts.length} delivery receipt(s)`,
                            )
                          }
                        >
                          Message details
                        </button>
                      </div>
                    </details>
                  )}
                </motion.article>
              );
            })}
            {pending.map((p) => (
              <div key={p.clientId} className="message-row own">
                <div className="bubble pending">
                  <p dir="auto">{p.body || "Attachment"}</p>
                  {p.failed ? (
                    <button className="error" onClick={() => send(p)}>
                      Failed · retry
                    </button>
                  ) : (
                    <small>Sending…</small>
                  )}
                </div>
              </div>
            ))}
          </>
        )}
        <div ref={end} />
      </div>
      {error && (
        <div className="chat-error" role="alert">
          {error}
          <button aria-label="Dismiss error" onClick={() => setError("")}>
            <X size={14} />
          </button>
        </div>
      )}
      <div className="composer-zone">
        {reply && (
          <div className="reply-preview">
            <Reply size={16} />
            <div>
              <strong>Replying to {reply.sender.displayName}</strong>
              <p dir="auto">{reply.body}</p>
            </div>
            <button
              className="icon"
              aria-label="Cancel reply"
              onClick={() => setReply(null)}
            >
              <X size={15} />
            </button>
          </div>
        )}
        {attachment && (
          <div className="reply-preview">
            <FileText size={16} />
            {attachment.filename}
            <button
              className="icon"
              aria-label="Remove attachment"
              onClick={() => setAttachment(null)}
            >
              <X size={15} />
            </button>
          </div>
        )}
        {upload !== null && (
          <progress aria-label="Upload progress" value={upload} max={100} />
        )}
        <div className="composer">
          <input
            ref={file}
            type="file"
            hidden
            accept="image/png,image/jpeg,image/webp,application/pdf,audio/ogg,video/mp4"
            onChange={(e: ChangeEvent<HTMLInputElement>) => {
              if (e.target.files?.[0]) uploadFile(e.target.files[0]);
              e.target.value = "";
            }}
          />
          <div className="composer-pill">
            <button
              className="icon"
              aria-label="Attach a file"
              disabled={!uploads || upload !== null}
              onClick={() => file.current?.click()}
            >
              <Paperclip size={20} />
            </button>
            <textarea
              aria-label="Write a message"
              placeholder="Write a little something…"
              dir="auto"
              rows={1}
              maxLength={16000}
              value={draft}
              onChange={(e) => {
                setDraft(e.target.value);
                if (Date.now() - typingLast.current > 1500) {
                  socket?.emit("typing", { conversationId: chat.id });
                  typingLast.current = Date.now();
                }
              }}
              onKeyDown={(e) => {
                if (
                  e.key === "Enter" &&
                  !e.shiftKey &&
                  !e.nativeEvent.isComposing
                ) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            <button
              className="icon"
              aria-label="Open emoji picker"
              onClick={() => setEmoji(!emoji)}
            >
              <Smile size={20} />
            </button>
          </div>
          <button
            className="send"
            aria-label="Send message"
            disabled={(!draft.trim() && !attachment) || upload !== null}
            onClick={() => send()}
          >
            <ArrowUp size={23} />
          </button>
          {emoji && (
            <div className="emoji-picker">
              {[
                "❤️",
                "✨",
                "😊",
                "👍",
                "😂",
                "🎉",
                "🌙",
                "☕",
                "👀",
                "🫶",
                "🌿",
                "💭",
              ].map((em) => (
                <button
                  key={em}
                  onClick={() => {
                    setDraft(draft + em);
                    setEmoji(false);
                  }}
                >
                  {em}
                </button>
              ))}
            </div>
          )}
        </div>
        <p className="composer-hint">
          Enter to send <span>·</span> Shift + Enter for a new line
        </p>
      </div>
    </section>
  );
}
