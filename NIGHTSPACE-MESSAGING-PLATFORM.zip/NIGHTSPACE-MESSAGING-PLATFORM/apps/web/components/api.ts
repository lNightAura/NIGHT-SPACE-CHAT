export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export async function api<T>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const response = await fetch("/api" + path, {
    method,
    credentials: "same-origin",
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    cache: "no-store",
  });
  if (!response.ok) {
    const result = await response
      .json()
      .catch(() => ({ error: "Network request failed" }));
    throw new ApiError(result.error || "Request failed", response.status);
  }
  return response.status === 204 ? (undefined as T) : response.json();
}
export const errorMessage = (e: unknown) =>
  e instanceof Error ? e.message : "An unexpected error occurred";
export type Capabilities = {
  e2ee: boolean;
  serverReadableMessaging: boolean;
  calls: boolean;
  captchaRequired: boolean;
  captchaSiteKey: string;
  uploads: boolean;
};
