"use client";
import { useState, type FormEvent } from "react";
import type { PublicUser } from "@nightspace/shared";
import { Modal } from "./primitives";
import { api, errorMessage } from "./api";
export function NewConversation({
  close,
  created,
}: {
  close: () => void;
  created: (id: string) => void;
}) {
  const [kind, setKind] = useState("DIRECT"),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const data = new FormData(e.currentTarget);
    try {
      const ids: string[] = [];
      if (kind !== "SAVED")
        for (const name of String(data.get("username"))
          .split(",")
          .map((x) => x.trim())
          .filter(Boolean)) {
          const users = await api<PublicUser[]>(
            "/users?username=" + encodeURIComponent(name),
          );
          if (!users[0]) throw new Error("No account found for @" + name);
          ids.push(users[0].id);
        }
      const result = await api<{ id: string }>("/conversations", "POST", {
        kind,
        userIds: ids,
        ...(kind === "GROUP" ? { title: data.get("title") } : {}),
      });
      created(result.id);
      close();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title="A new conversation" close={close}>
      <p className="subtle">Every connection starts somewhere.</p>
      <form onSubmit={submit}>
        <label>
          Conversation type
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="DIRECT">One-to-one</option>
            <option value="GROUP">Group</option>
            <option value="SAVED">Saved Messages · just you</option>
          </select>
        </label>
        {kind !== "SAVED" && (
          <label>
            {kind === "GROUP"
              ? "Usernames, separated by commas"
              : "Exact username"}
            <input
              name="username"
              required
              placeholder={kind === "GROUP" ? "aurora, atlas" : "aurora"}
              autoFocus
            />
          </label>
        )}
        {kind === "GROUP" && (
          <label>
            Group name
            <input name="title" maxLength={100} required />
          </label>
        )}
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        <button className="primary" disabled={busy}>
          {busy ? "Connecting…" : "Start a conversation"}
        </button>
      </form>
    </Modal>
  );
}
