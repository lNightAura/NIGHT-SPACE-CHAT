"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";
import { MotionConfig } from "framer-motion";
import {
  MessageCircle,
  Settings2,
  Plus,
  Search,
  Archive,
  Bookmark,
  LogOut,
  ArrowUpRight,
  Sparkles,
  Orbit,
} from "lucide-react";
import type { Account, Chat } from "@nightspace/shared";
import { api, errorMessage, ApiError, type Capabilities } from "./api";
import { Auth } from "./Auth";
import { Settings, applyTheme } from "./Settings";
import { NewConversation } from "./NewConversation";
import { ChatPanel, chatTitle } from "./ChatPanel";
import { Avatar, Brand } from "./primitives";
export function Nightspace() {
  const [user, setUser] = useState<Account | null>(null),
    [ready, setReady] = useState(false),
    [capabilities, setCapabilities] = useState<Capabilities | null>(null),
    [chats, setChats] = useState<Chat[]>([]),
    [active, setActive] = useState<string | null>(null),
    [socket, setSocket] = useState<Socket | null>(null),
    [connected, setConnected] = useState(false),
    [settings, setSettings] = useState(false),
    [newChat, setNewChat] = useState(false),
    [filter, setFilter] = useState("All messages"),
    [search, setSearch] = useState(""),
    [notice, setNotice] = useState(""),
    [initError, setInitError] = useState(""),
    [typing, setTyping] = useState<Record<string, number>>({}),
    [tick, setTick] = useState(0);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toast = useCallback((s: string) => {
    setNotice(s);
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setNotice(""), 6000);
  }, []);
  const refresh = useCallback(async () => {
    setChats(await api<Chat[]>("/conversations"));
  }, []);
  useEffect(() => {
    api<Capabilities>("/capabilities")
      .then(setCapabilities)
      .catch((e) => setInitError(errorMessage(e)));
    api<Account>("/me")
      .then((u) => {
        setUser(u);
        applyTheme(u.theme, u.accent);
      })
      .catch((e) => {
        if (!(e instanceof ApiError && e.status === 401))
          setInitError(errorMessage(e));
      })
      .finally(() => setReady(true));
    return () => {
      if (noticeTimer.current) clearTimeout(noticeTimer.current);
    };
  }, []);
  useEffect(() => {
    if (!user?.id) return;
    let alive = true;
    refresh().catch((e) => toast(errorMessage(e)));
    const s = io({
      addTrailingSlash: false,
      transports: ["websocket", "polling"],
      tryAllTransports: true,
      withCredentials: true,
    });
    setSocket(s);
    const sync = () => refresh().catch((e) => toast(errorMessage(e)));
    s.on("connect", () => {
      setConnected(true);
      sync();
    });
    s.on("disconnect", () => setConnected(false));
    s.on("connect_error", () => setConnected(false));
    s.on("message.new", sync);
    s.on("messages.updated", sync);
    s.on("conversation.updated", sync);
    s.on("profile.updated", () =>
      api<Account>("/me")
        .then((u) => {
          if (alive) {
            setUser(u);
            applyTheme(u.theme, u.accent);
          }
        })
        .catch(() => {}),
    );
    s.on("typing", (data: { conversationId: string; userId: string }) => {
      if (data.userId !== user.id)
        setTyping((old) => ({
          ...old,
          [data.conversationId]: Date.now() + 3500,
        }));
    });
    const interval = setInterval(() => {
      setTick((t) => t + 1);
      sync();
    }, 10000);
    return () => {
      alive = false;
      s.disconnect();
      setSocket(null);
      clearInterval(interval);
    };
  }, [user?.id, refresh, toast]);
  const logout = () => {
    setUser(null);
    setChats([]);
    setActive(null);
    setSettings(false);
    applyTheme("Luxury Cream");
  };
  async function saved() {
    try {
      const chat = await api<{ id: string }>("/conversations", "POST", {
        kind: "SAVED",
        userIds: [],
      });
      await refresh();
      setActive(chat.id);
      setFilter("All messages");
    } catch (e) {
      toast(errorMessage(e));
    }
  }
  if (!ready)
    return (
      <main className="splash">
        <Orbit size={44} />
        <Brand />
        <span>Making room for you…</span>
      </main>
    );
  if (!user)
    return (
      <>
        <Auth
          capabilities={capabilities}
          onLogin={(u) => {
            setUser(u);
            applyTheme(u.theme, u.accent);
          }}
        />
        {initError && (
          <div className="toast" role="alert">
            {initError}. Start the API and dependencies, then reload.
          </div>
        )}
      </>
    );
  const folders = [...new Set(chats.map((c) => c.folder).filter(Boolean))];
  const filtered = chats
    .filter(
      (c) =>
        (filter === "Archived" ? c.archived : !c.archived) &&
        (filter === "Unread"
          ? c.unread > 0
          : filter === "Groups"
            ? c.kind === "GROUP"
            : folders.includes(filter)
              ? c.folder === filter
              : true) &&
        chatTitle(c, user).toLowerCase().includes(search.toLowerCase()),
    )
    .sort(
      (a, b) =>
        Number(b.pinned) - Number(a.pinned) ||
        new Date(b.messages[0]?.createdAt || 0).getTime() -
          new Date(a.messages[0]?.createdAt || 0).getTime(),
    );
  const chat = chats.find((c) => c.id === active);
  const unread = chats.reduce((a, c) => a + c.unread, 0);
  return (
    <MotionConfig reducedMotion="user">
      <main className={"workspace " + (active ? "has-active" : "")}>
        <nav className="rail" aria-label="Main navigation">
          <button
            className="rail-logo"
            aria-label="NIGHTSPACE home"
            onClick={() => setActive(null)}
          >
            <Orbit size={28} />
          </button>
          <div className="rail-items">
            <button
              className={filter !== "Archived" ? "selected" : ""}
              aria-label="Messages"
              onClick={() => {
                setFilter("All messages");
                setActive(null);
              }}
            >
              <MessageCircle size={23} />
              {unread > 0 && <i />}
            </button>
            <button aria-label="Saved messages" onClick={saved}>
              <Bookmark size={22} />
            </button>
            <button
              aria-label="Archived conversations"
              onClick={() => {
                setFilter("Archived");
                setActive(null);
              }}
            >
              <Archive size={22} />
            </button>
          </div>
          <div className="rail-bottom">
            <button aria-label="Settings" onClick={() => setSettings(true)}>
              <Settings2 size={22} />
            </button>
            <button
              aria-label="Sign out"
              onClick={async () => {
                try {
                  await api("/auth/logout", "POST");
                  logout();
                } catch (e) {
                  toast(errorMessage(e));
                }
              }}
            >
              <LogOut size={20} />
            </button>
            <button
              className="profile-button"
              aria-label="My profile"
              onClick={() => setSettings(true)}
            >
              <Avatar name={user.displayName} small />
            </button>
          </div>
        </nav>
        <aside className="conversation-list">
          <div className="list-brand">
            <Brand />
            <span
              className={"connection-dot " + (connected ? "online" : "")}
              title={
                connected
                  ? "Realtime connected"
                  : "Reconnecting; periodic sync active"
              }
            />
          </div>
          <header className="list-heading">
            <div>
              <span className="eyebrow">YOUR EVERYDAY CONNECTIONS</span>
              <h1>
                Messages<span>.</span>
              </h1>
            </div>
            <button
              className="new-chat"
              aria-label="New conversation"
              onClick={() => setNewChat(true)}
            >
              <Plus size={22} />
            </button>
          </header>
          <div className="list-search">
            <Search size={17} />
            <input
              aria-label="Search conversations"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Find a conversation"
            />
            <kbd>⌕</kbd>
          </div>
          <div className="chat-filters">
            {[
              "All messages",
              "Unread",
              "Groups",
              ...(filter === "Archived" ? ["Archived"] : []),
              ...folders,
            ].map((f) => (
              <button
                key={f}
                className={filter === f ? "active" : ""}
                onClick={() => setFilter(f)}
              >
                {f}
                {f === "Unread" && unread > 0 && <span>{unread}</span>}
              </button>
            ))}
          </div>
          <div className="list-scroll">
            {filtered.length === 0 ? (
              <div className="list-empty">
                <MessageCircle size={26} />
                <h3>
                  {search
                    ? "No matches, just yet."
                    : "A quieter kind of inbox."}
                </h3>
                <p>
                  {search
                    ? "Try a different name."
                    : "Start a conversation and make this space your own."}
                </p>
                <button onClick={() => setNewChat(true)}>
                  Say hello <ArrowUpRight size={14} />
                </button>
              </div>
            ) : (
              filtered.map((c) => (
                <button
                  key={c.id}
                  className={"chat-item " + (active === c.id ? "active" : "")}
                  onClick={() => setActive(c.id)}
                >
                  <Avatar name={chatTitle(c, user)} />
                  <span className="chat-item-copy">
                    <span className="chat-item-top">
                      <strong>{chatTitle(c, user)}</strong>
                      <time>
                        {c.messages[0]
                          ? new Date(
                              c.messages[0].createdAt,
                            ).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })
                          : ""}
                      </time>
                    </span>
                    <span className="chat-item-bottom">
                      <span dir="auto">
                        {typing[c.id] > Date.now() + tick * 0
                          ? "typing…"
                          : c.messages[0]?.deletedAt
                            ? "Message deleted"
                            : c.messages[0]?.body ||
                              c.messages[0]?.attachment?.filename ||
                              "The beginning of something good."}
                      </span>
                      {c.unread > 0 ? (
                        <b>{c.unread}</b>
                      ) : c.pinned ? (
                        <Bookmark size={12} />
                      ) : null}
                    </span>
                  </span>
                </button>
              ))
            )}
          </div>
          <footer className="list-footer">
            <Sparkles size={17} />
            <div>
              Room for every conversation.
              <small>No message credits. No subscription limits.</small>
            </div>
          </footer>
        </aside>
        {chat ? (
          <ChatPanel
            key={chat.id}
            chat={chat}
            user={user}
            socket={socket}
            back={() => setActive(null)}
            refresh={refresh}
            toast={toast}
            typing={typing[chat.id] > Date.now()}
            uploads={capabilities?.uploads ?? false}
          />
        ) : (
          <section className="welcome-panel">
            <span className="eyebrow">WELCOME TO YOUR CORNER OF THE WORLD</span>
            <div className="welcome-mark">
              <Orbit size={64} />
            </div>
            <h2>
              A little less noise.
              <br />
              <em>A little more connection.</em>
            </h2>
            <p>
              Your people. Your thoughts. Your space.
              <br />
              Choose a conversation or start something new.
            </p>
            <button className="primary" onClick={() => setNewChat(true)}>
              Start a conversation <ArrowUpRight size={18} />
            </button>
            <div className="welcome-disclosure">
              DEVELOPMENT MILESTONE
              <br />
              Messages are server-readable. E2EE and audio calls are not yet
              available.
            </div>
          </section>
        )}
        {settings && (
          <Settings
            user={user}
            onUser={setUser}
            close={() => setSettings(false)}
            onLogout={logout}
            toast={toast}
          />
        )}{" "}
        {newChat && (
          <NewConversation
            close={() => setNewChat(false)}
            created={(id) => {
              refresh()
                .then(() => setActive(id))
                .catch((e) => toast(errorMessage(e)));
            }}
          />
        )}
        {notice && (
          <div className="toast" role="status">
            {notice}
          </div>
        )}
      </main>
    </MotionConfig>
  );
}
