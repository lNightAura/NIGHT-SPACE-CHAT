export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public code = "REQUEST_FAILED",
  ) {
    super(message);
  }
}
export const requireValue = (
  condition: unknown,
  status: number,
  message: string,
): asserts condition => {
  if (!condition) throw new HttpError(status, message);
};
