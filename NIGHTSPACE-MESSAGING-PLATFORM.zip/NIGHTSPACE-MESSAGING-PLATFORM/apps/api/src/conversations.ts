import { Router } from "express";
import { z } from "zod";
import { publicUserSelect } from "@nightspace/shared";
import { db } from "./db.js";
import { actor, membership, id, rate } from "./security.js";
import { HttpError } from "./errors.js";
import { messageInclude } from "./messages.js";
import { emitConversation } from "./realtime.js";
export const conversations = Router();
conversations.get("/conversations", async (req, res) => {
  const userId = actor(req).userId;
  const rows = await db.member.findMany({
    where: { userId },
    include: {
      conversation: {
        include: {
          members: {
            include: {
              user: { select: { ...publicUserSelect, readReceipts: true } },
            },
          },
          messages: {
            where: { hidden: { none: { userId } } },
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            take: 1,
            include: messageInclude,
          },
        },
      },
    },
    orderBy: [{ pinned: "desc" }, { conversation: { createdAt: "desc" } }],
  });
  res.json(
    await Promise.all(
      rows.map(async (row) => ({
        ...row.conversation,
        pinned: row.pinned,
        archived: row.archived,
        muted: row.muted,
        folder: row.folder,
        members: row.conversation.members.map((m) => ({
          userId: m.userId,
          user: m.user,
          lastReadAt:
            m.user.readReceipts || m.userId === userId
              ? m.lastReadAt
              : new Date(0),
        })),
        unread: await db.message.count({
          where: {
            conversationId: row.conversationId,
            senderId: { not: userId },
            createdAt: { gt: row.lastReadAt },
            deletedAt: null,
            hidden: { none: { userId } },
          },
        }),
      })),
    ),
  );
});
conversations.post(
  "/conversations",
  rate("conversation", 30),
  async (req, res) => {
    const userId = actor(req).userId;
    const input = z
      .object({
        userIds: z.array(z.uuid()),
        title: z.string().trim().min(1).max(100).optional(),
        kind: z.enum(["DIRECT", "GROUP", "SAVED"]).default("DIRECT"),
      })
      .strict()
      .parse(req.body);
    const ids = [...new Set([userId, ...input.userIds])];
    if (input.kind === "DIRECT" && ids.length !== 2)
      throw new HttpError(400, "Direct conversation requires one other user");
    if (input.kind === "SAVED" && ids.length !== 1)
      throw new HttpError(400, "Saved messages are private");
    if (input.kind === "GROUP" && !input.title)
      throw new HttpError(400, "Group title required");
    if ((await db.user.count({ where: { id: { in: ids } } })) !== ids.length)
      throw new HttpError(400, "Unknown member");
    if (
      await db.block.findFirst({
        where: {
          OR: [
            { userId, targetId: { in: ids } },
            { targetId: userId, userId: { in: ids } },
          ],
        },
      })
    )
      throw new HttpError(403, "Conversation unavailable");
    const directKey =
      input.kind === "DIRECT"
        ? ids.sort().join(":")
        : input.kind === "SAVED"
          ? "saved:" + userId
          : null;
    const data = {
      kind: input.kind,
      title: input.title,
      directKey,
      members: {
        create: ids.map((uid) => ({
          userId: uid,
          role: uid === userId ? "ADMIN" : "MEMBER",
        })),
      },
    };
    const chat = directKey
      ? await db.conversation.upsert({
          where: { directKey },
          create: data,
          update: {},
        })
      : await db.conversation.create({ data });
    await emitConversation(chat.id, "conversation.updated", {
      conversationId: chat.id,
    });
    res.status(201).json(chat);
  },
);
conversations.patch("/conversations/:id", async (req, res) => {
  const userId = actor(req).userId,
    conversationId = id(req.params.id);
  await membership(userId, conversationId);
  const input = z
    .object({
      pinned: z.boolean().optional(),
      archived: z.boolean().optional(),
      muted: z.boolean().optional(),
      folder: z.string().max(40).optional(),
    })
    .strict()
    .parse(req.body);
  res.json(
    await db.member.update({
      where: { userId_conversationId: { userId, conversationId } },
      data: input,
    }),
  );
});
conversations.post(
  "/conversations/:id/members",
  rate("member-add", 30),
  async (req, res) => {
    const conversationId = id(req.params.id),
      userId = actor(req).userId;
    const m = await membership(userId, conversationId);
    const chat = await db.conversation.findUniqueOrThrow({
      where: { id: conversationId },
    });
    if (m.role !== "ADMIN" || chat.kind !== "GROUP")
      throw new HttpError(403, "Group administrator required");
    const targetId = id(req.body.userId);
    if (
      await db.block.findFirst({
        where: {
          OR: [
            { userId, targetId },
            { userId: targetId, targetId: userId },
          ],
        },
      })
    )
      throw new HttpError(403, "Member unavailable");
    await db.member.upsert({
      where: { userId_conversationId: { userId: targetId, conversationId } },
      create: { userId: targetId, conversationId },
      update: {},
    });
    await emitConversation(conversationId, "conversation.updated", {
      conversationId,
    });
    res.status(204).end();
  },
);
conversations.delete("/conversations/:id/members/:userId", async (req, res) => {
  const conversationId = id(req.params.id),
    userId = actor(req).userId,
    targetId = id(req.params.userId);
  const m = await membership(userId, conversationId);
  const chat = await db.conversation.findUniqueOrThrow({
    where: { id: conversationId },
  });
  if (m.role !== "ADMIN" || chat.kind !== "GROUP" || targetId === userId)
    throw new HttpError(
      403,
      "Group administrator required; owner cannot be removed",
    );
  await db.member.deleteMany({
    where: { conversationId, userId: targetId, role: { not: "ADMIN" } },
  });
  await emitConversation(conversationId, "conversation.updated", {
    conversationId,
  });
  res.status(204).end();
});
