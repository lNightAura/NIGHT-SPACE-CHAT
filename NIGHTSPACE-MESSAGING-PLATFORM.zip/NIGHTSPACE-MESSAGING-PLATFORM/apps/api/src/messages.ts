import { Router } from "express";
import { Prisma } from "@prisma/client";
import { z } from "zod";
import { messageInput, publicUserSelect } from "@nightspace/shared";
import { db } from "./db.js";
import { config } from "./config.js";
import { actor, membership, canSend, id, rate } from "./security.js";
import { HttpError } from "./errors.js";
import { emitConversation } from "./realtime.js";
export const messageInclude = {
  sender: { select: publicUserSelect },
  replyTo: {
    select: { id: true, body: true, senderId: true, deletedAt: true },
  },
  attachment: { select: { id: true, filename: true, mime: true, size: true } },
  reactions: { select: { userId: true, emoji: true } },
  receipts: { select: { userId: true, deliveredAt: true } },
} satisfies Prisma.MessageInclude;
export function decodeCursor(
  raw: unknown,
): { createdAt: Date; id: string } | null {
  if (raw === undefined) return null;
  if (typeof raw !== "string" || raw.length > 256)
    throw new HttpError(400, "Invalid cursor");
  try {
    const v = z
      .object({ createdAt: z.iso.datetime(), id: z.uuid() })
      .strict()
      .parse(JSON.parse(Buffer.from(raw, "base64url").toString()));
    return { createdAt: new Date(v.createdAt), id: v.id };
  } catch {
    throw new HttpError(400, "Invalid cursor");
  }
}
export const messages = Router();
messages.get(
  "/conversations/:id/messages",
  rate("history", 120),
  async (req, res) => {
    const userId = actor(req).userId,
      conversationId = id(req.params.id);
    await membership(userId, conversationId);
    const cursor = decodeCursor(req.query.cursor);
    const search = z.string().max(200).optional().parse(req.query.search);
    const rows = await db.message.findMany({
      where: {
        conversationId,
        hidden: { none: { userId } },
        ...(search
          ? { body: { contains: search, mode: "insensitive" as const } }
          : {}),
        ...(cursor
          ? {
              OR: [
                { createdAt: { lt: cursor.createdAt } },
                { createdAt: cursor.createdAt, id: { lt: cursor.id } },
              ],
            }
          : {}),
      },
      include: messageInclude,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 51,
    });
    const hasMore = rows.length > 50;
    const page = rows.slice(0, 50),
      last = page.at(-1);
    res.json({
      messages: page.reverse(),
      nextCursor:
        hasMore && last
          ? Buffer.from(
              JSON.stringify({
                createdAt: last.createdAt.toISOString(),
                id: last.id,
              }),
            ).toString("base64url")
          : null,
    });
  },
);
messages.post(
  "/conversations/:id/messages",
  rate("send", 120),
  async (req, res) => {
    if (config.REQUIRE_E2EE)
      throw new HttpError(
        503,
        "E2EE is required but not available in this milestone",
        "E2EE_UNAVAILABLE",
      );
    const userId = actor(req).userId,
      conversationId = id(req.params.id);
    await canSend(userId, conversationId);
    const input = messageInput.parse(req.body);
    if (
      input.replyToId &&
      !(await db.message.findFirst({
        where: { id: input.replyToId, conversationId, deletedAt: null },
      }))
    )
      throw new HttpError(400, "Invalid reply");
    if (
      input.attachmentId &&
      !(await db.attachment.findFirst({
        where: { id: input.attachmentId, conversationId, ownerId: userId },
      }))
    )
      throw new HttpError(400, "Invalid attachment");
    let msg;
    try {
      msg = await db.message.create({
        data: { ...input, conversationId, senderId: userId },
        include: messageInclude,
      });
    } catch (e) {
      if (!(
        e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002"
      ))
        throw e;
      msg = await db.message.findUniqueOrThrow({
        where: {
          senderId_clientId: { senderId: userId, clientId: input.clientId },
        },
        include: messageInclude,
      });
      if (
        msg.conversationId !== conversationId ||
        msg.body !== input.body ||
        msg.replyToId !== (input.replyToId ?? null) ||
        msg.attachmentId !== (input.attachmentId ?? null)
      )
        throw new HttpError(
          409,
          "Retry key already used for different content",
        );
    }
    await emitConversation(conversationId, "message.new", msg);
    res.status(201).json(msg);
  },
);
messages.post("/conversations/:id/read", async (req, res) => {
  const conversationId = id(req.params.id),
    userId = actor(req).userId;
  await membership(userId, conversationId);
  const last = await db.message.findFirst({
    where: { conversationId },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    select: { createdAt: true },
  });
  await db.member.update({
    where: { userId_conversationId: { userId, conversationId } },
    data: { lastReadAt: last?.createdAt || new Date(0) },
  });
  const user = await db.user.findUniqueOrThrow({
    where: { id: userId },
    select: { readReceipts: true },
  });
  if (user.readReceipts)
    await emitConversation(conversationId, "conversation.updated", {
      conversationId,
    });
  res.status(204).end();
});
messages.patch("/messages/:id", rate("edit", 60), async (req, res) => {
  const messageId = id(req.params.id),
    userId = actor(req).userId;
  const input = z
    .object({ body: z.string().trim().min(1).max(16000) })
    .strict()
    .parse(req.body);
  const msg = await db.message.findUnique({ where: { id: messageId } });
  if (!msg || msg.senderId !== userId || msg.deletedAt)
    throw new HttpError(404, "Message not found");
  await canSend(userId, msg.conversationId);
  const updated = await db.message.update({
    where: { id: messageId },
    data: { body: input.body, editedAt: new Date() },
    include: messageInclude,
  });
  await emitConversation(msg.conversationId, "messages.updated", {
    conversationId: msg.conversationId,
  });
  res.json(updated);
});
messages.delete("/messages/:id", rate("delete", 120), async (req, res) => {
  const messageId = id(req.params.id),
    userId = actor(req).userId;
  const msg = await db.message.findUnique({ where: { id: messageId } });
  if (!msg) throw new HttpError(404, "Message not found");
  await membership(userId, msg.conversationId);
  const scope = z.enum(["me", "everyone"]).parse(req.query.scope || "me");
  if (scope === "everyone") {
    if (msg.senderId !== userId)
      throw new HttpError(403, "Only sender may delete for everyone");
    await db.message.update({
      where: { id: messageId },
      data: { body: "", deletedAt: new Date(), attachmentId: null },
    });
    await emitConversation(msg.conversationId, "messages.updated", {
      conversationId: msg.conversationId,
    });
  } else {
    await db.hiddenMessage.upsert({
      where: { messageId_userId: { messageId, userId } },
      create: { messageId, userId },
      update: {},
    });
  }
  res.status(204).end();
});
messages.post(
  "/messages/:id/reactions",
  rate("react", 60),
  async (req, res) => {
    const messageId = id(req.params.id),
      userId = actor(req).userId;
    const { emoji } = z
      .object({ emoji: z.enum(["❤️", "👍", "✨", "😂", "🎉", "👀"]) })
      .strict()
      .parse(req.body);
    const msg = await db.message.findUnique({ where: { id: messageId } });
    if (!msg || msg.deletedAt) throw new HttpError(404, "Message not found");
    await canSend(userId, msg.conversationId);
    const key = { messageId, userId, emoji };
    const old = await db.reaction.findUnique({
      where: { messageId_userId_emoji: key },
    });
    if (old)
      await db.reaction.delete({ where: { messageId_userId_emoji: key } });
    else
      await db.reaction.upsert({
        where: { messageId_userId_emoji: key },
        create: key,
        update: {},
      });
    await emitConversation(msg.conversationId, "messages.updated", {
      conversationId: msg.conversationId,
    });
    res.status(204).end();
  },
);
