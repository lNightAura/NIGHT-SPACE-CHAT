import { Router } from "express";
import * as argon2 from "argon2";
import { Prisma } from "@prisma/client";
import {
  registration,
  login,
  profileInput,
  publicUserSelect,
  password,
} from "@nightspace/shared";
import { z } from "zod";
import { unlink } from "node:fs/promises";
import path from "node:path";
import { db } from "./db.js";
import { config, cookieName } from "./config.js";
import {
  actor,
  authenticate,
  rate,
  captcha,
  issueSession,
  options,
  audit,
  id,
  digest,
  limitKey,
} from "./security.js";
import { HttpError } from "./errors.js";
import { disconnectSession, disconnectUser, emitUser } from "./realtime.js";
export const accountSelect = {
  ...publicUserSelect,
  role: true,
  theme: true,
  accent: true,
  readReceipts: true,
  typingVisible: true,
};
const hashOptions = {
  type: argon2.argon2id,
  memoryCost: 19456,
  timeCost: 2,
  parallelism: 1,
};
// Equal-cost dummy verification reduces timing-based username enumeration.
const dummy = argon2.hash("not-a-real-account-password", hashOptions);
export const auth = Router();
auth.post("/auth/register", rate("registration", 5, 600), async (req, res) => {
  const input = registration.parse(req.body);
  await captcha(input.captchaToken, "register");
  const passwordHash = await argon2.hash(input.password, hashOptions);
  try {
    const user = await db.user.create({
      data: {
        username: input.username,
        displayName: input.displayName,
        passwordHash,
      },
      select: accountSelect,
    });
    await issueSession(user.id, res);
    await audit("REGISTER", user.id);
    res.status(201).json(user);
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002")
      throw new HttpError(409, "Unable to create account with those details");
    throw e;
  }
});
auth.post("/auth/login", rate("login", 15, 300), async (req, res) => {
  const input = login.parse(req.body);
  await limitKey("login:account:" + input.username, 15, 300);
  await captcha(input.captchaToken, "login");
  const user = await db.user.findUnique({
    where: { username: input.username },
  });
  const valid = await argon2.verify(
    user?.passwordHash || (await dummy),
    input.password,
  );
  if (!user || !valid) {
    await audit("LOGIN_FAILED");
    throw new HttpError(401, "Invalid username or password");
  }
  const old = req.cookies?.[cookieName];
  if (typeof old === "string") {
    const sessions = await db.session.findMany({
      where: { tokenHash: digest(old) },
    });
    await db.session.deleteMany({ where: { tokenHash: digest(old) } });
    for (const s of sessions) disconnectSession(s.id);
  }
  await issueSession(user.id, res);
  await audit("LOGIN", user.id);
  res.json(
    await db.user.findUnique({ where: { id: user.id }, select: accountSelect }),
  );
});
auth.use(authenticate);
auth.post("/auth/logout", async (req, res) => {
  const a = actor(req);
  await db.session.deleteMany({ where: { id: a.sessionId } });
  disconnectSession(a.sessionId);
  res.clearCookie(cookieName, options).status(204).end();
});
auth.post("/auth/logout-all", async (req, res) => {
  const a = actor(req);
  await db.session.deleteMany({ where: { userId: a.userId } });
  disconnectUser(a.userId);
  res.clearCookie(cookieName, options).status(204).end();
});
auth.get("/me", async (req, res) => {
  res.json(
    await db.user.findUnique({
      where: { id: actor(req).userId },
      select: accountSelect,
    }),
  );
});
auth.patch("/me", rate("profile", 30), async (req, res) => {
  const user = await db.user.update({
    where: { id: actor(req).userId },
    data: profileInput.parse(req.body),
    select: accountSelect,
  });
  emitUser(user.id, "profile.updated", {});
  res.json(user);
});
auth.post("/me/password", rate("password", 5, 600), async (req, res) => {
  const a = actor(req);
  const input = z
    .object({ currentPassword: z.string().max(128), newPassword: password })
    .strict()
    .parse(req.body);
  const user = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  if (!(await argon2.verify(user.passwordHash, input.currentPassword)))
    throw new HttpError(401, "Password incorrect");
  await db.$transaction([
    db.user.update({
      where: { id: a.userId },
      data: { passwordHash: await argon2.hash(input.newPassword, hashOptions) },
    }),
    db.session.deleteMany({ where: { userId: a.userId } }),
  ]);
  disconnectUser(a.userId);
  await issueSession(a.userId, res);
  await audit("PASSWORD_CHANGED", a.userId);
  res.status(204).end();
});
auth.get("/sessions", async (req, res) => {
  const a = actor(req);
  const sessions = await db.session.findMany({
    where: { userId: a.userId },
    select: { id: true, createdAt: true, expiresAt: true },
    orderBy: { createdAt: "desc" },
  });
  res.json(sessions.map((s) => ({ ...s, current: s.id === a.sessionId })));
});
auth.delete("/sessions/:id", async (req, res) => {
  const sessionId = id(req.params.id);
  const removed = await db.session.deleteMany({
    where: { id: sessionId, userId: actor(req).userId },
  });
  if (removed.count) disconnectSession(sessionId);
  res.status(204).end();
});
auth.get("/me/export", rate("export", 2, 600), async (req, res) => {
  const userId = actor(req).userId;
  const [profile, members] = await Promise.all([
    db.user.findUnique({ where: { id: userId }, select: accountSelect }),
    db.member.findMany({ where: { userId } }),
  ]);
  res.setHeader(
    "Content-Disposition",
    'attachment; filename="nightspace-account.json"',
  );
  res.setHeader("Content-Type", "application/json");
  res.write(
    JSON.stringify({
      profile,
      members,
      notice:
        "Authored messages only; attachment binaries not included. Not a transactional snapshot.",
    }).slice(0, -1) + ',"messages":[',
  );
  let cursor: string | undefined,
    first = true;
  while (!res.destroyed) {
    const page = await db.message.findMany({
      where: { senderId: userId },
      orderBy: { id: "asc" },
      take: 250,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      select: { id: true, conversationId: true, body: true, createdAt: true },
    });
    if (!page.length) break;
    for (const message of page) {
      if (res.destroyed) return;
      const chunk = (first ? "" : ",") + JSON.stringify(message);
      first = false;
      if (!res.write(chunk))
        await new Promise<void>((resolve) => {
          const done = () => {
            res.off("drain", done);
            res.off("close", done);
            resolve();
          };
          res.once("drain", done);
          res.once("close", done);
        });
    }
    cursor = page.at(-1)!.id;
  }
  if (!res.destroyed) res.end("]}");
});
auth.delete("/me", rate("delete-account", 3, 600), async (req, res) => {
  const a = actor(req);
  const { password } = z
    .object({ password: z.string().max(128) })
    .strict()
    .parse(req.body);
  const user = await db.user.findUniqueOrThrow({ where: { id: a.userId } });
  if (!(await argon2.verify(user.passwordHash, password)))
    throw new HttpError(401, "Password incorrect");
  const files = await db.attachment.findMany({
    where: { ownerId: a.userId },
    select: { diskKey: true },
  });
  await db.$transaction([
    db.message.updateMany({
      where: { senderId: a.userId },
      data: { body: "", deletedAt: new Date() },
    }),
    db.user.delete({ where: { id: a.userId } }),
  ]);
  for (const f of files)
    await unlink(path.join(path.resolve(config.UPLOAD_DIR), f.diskKey)).catch(
      () => {},
    );
  disconnectUser(a.userId);
  res.clearCookie(cookieName, options).status(204).end();
});
