import { PrismaClient } from "@prisma/client";
import { Redis } from "ioredis";
import { config } from "./config.js";
export const db = new PrismaClient();
export const redis = new Redis(config.REDIS_URL, {
  maxRetriesPerRequest: 1,
  lazyConnect: true,
});
redis.on("error", () => {
  /* Health endpoint exposes dependency failure; never log credentials. */
});
