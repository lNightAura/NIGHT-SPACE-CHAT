import type { Server as HttpServer } from "node:http";
import { Server } from "socket.io";
import { createAdapter } from "@socket.io/redis-adapter";
import { parse } from "cookie";
import { z } from "zod";
import { db, redis } from "./db.js";
import { config, cookieName } from "./config.js";
import { sessionFromToken, membership, canSend, limitKey } from "./security.js";
let io: Server | undefined;
export async function emitConversation(
  conversationId: string,
  event: string,
  payload: unknown,
) {
  const members = await db.member.findMany({
    where: { conversationId },
    select: { userId: true },
  });
  for (const m of members) io?.to("user:" + m.userId).emit(event, payload);
}
export function emitUser(userId: string, event: string, payload: unknown) {
  io?.to("user:" + userId).emit(event, payload);
}
export function disconnectSession(id: string) {
  io?.in("session:" + id).disconnectSockets(true);
}
export function disconnectUser(id: string) {
  io?.in("user:" + id).disconnectSockets(true);
}
export async function setupRealtime(server: HttpServer) {
  io = new Server(server, {
    path: "/socket.io",
    addTrailingSlash: false,
    maxHttpBufferSize: 8192,
    cors: { origin: config.WEB_ORIGIN, credentials: true },
    allowRequest: (req, done) =>
      done(null, req.headers.origin === config.WEB_ORIGIN),
    transports: ["websocket", "polling"],
  });
  const sub = redis.duplicate();
  await sub.connect();
  io.adapter(createAdapter(redis, sub));
  io.use(async (socket, next) => {
    try {
      await limitKey("socket:ip:" + socket.handshake.address, 40, 60);
      const s = await sessionFromToken(
        parse(socket.handshake.headers.cookie || "")[cookieName],
      );
      if (!s) return next(new Error("Unauthorized"));
      await limitKey("socket:account:" + s.userId, 40, 60);
      socket.data.identity = s;
      next();
    } catch {
      next(new Error("Connection denied"));
    }
  });
  io.on("connection", (socket) => {
    const s = socket.data.identity as {
      userId: string;
      sessionId: string;
      expiresAt: Date;
    };
    socket.join("user:" + s.userId);
    socket.join("session:" + s.sessionId);
    // Node timers overflow beyond about 24.8 days; re-arm long sessions safely.
    let expiry: ReturnType<typeof setTimeout>;
    const expire = () => {
      const remaining = s.expiresAt.getTime() - Date.now();
      if (remaining <= 0) socket.disconnect(true);
      else expiry = setTimeout(expire, Math.min(remaining, 2147483647));
    };
    expire();
    socket.on("disconnect", () => clearTimeout(expiry));
    const live = async () => {
      const sess = await db.session.findUnique({ where: { id: s.sessionId } });
      if (!sess || sess.expiresAt <= new Date()) {
        socket.disconnect(true);
        throw new Error("Expired");
      }
      await limitKey("socket:event:" + s.userId, 180, 60);
    };
    socket.on("typing", async (data) => {
      try {
        await live();
        const { conversationId } = z
          .object({ conversationId: z.uuid() })
          .strict()
          .parse(data);
        await canSend(s.userId, conversationId);
        const user = await db.user.findUniqueOrThrow({
          where: { id: s.userId },
          select: { typingVisible: true },
        });
        if (user.typingVisible) {
          await limitKey("typing:" + s.userId, 30, 10);
          await emitConversation(conversationId, "typing", {
            conversationId,
            userId: s.userId,
          });
        }
      } catch {
        /* no reflection of untrusted payloads */
      }
    });
    socket.on("message.received", async (data) => {
      try {
        await live();
        const { messageId } = z
          .object({ messageId: z.uuid() })
          .strict()
          .parse(data);
        const msg = await db.message.findUniqueOrThrow({
          where: { id: messageId },
        });
        await membership(s.userId, msg.conversationId);
        if (msg.senderId !== s.userId) {
          await db.receipt.upsert({
            where: { messageId_userId: { messageId, userId: s.userId } },
            create: { messageId, userId: s.userId },
            update: {},
          });
          await emitConversation(msg.conversationId, "messages.updated", {
            conversationId: msg.conversationId,
          });
        }
      } catch {
        /* bounded safe failure */
      }
    });
  });
  return async () => {
    await new Promise<void>((resolve) => io!.close(() => resolve()));
    await sub.quit();
  };
}
