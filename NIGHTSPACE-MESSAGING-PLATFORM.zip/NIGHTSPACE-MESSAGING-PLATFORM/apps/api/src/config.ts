import { config as dotenv } from "dotenv";
import { fileURLToPath } from "node:url";
import { z } from "zod";
dotenv({
  path: fileURLToPath(new URL("../../../.env", import.meta.url)),
  quiet: true,
});
// Compiled dist and src have identical path depth.
const bool = z.enum(["true", "false"]).transform((v) => v === "true");
const schema = z.object({
  NODE_ENV: z
    .enum(["development", "test", "production"])
    .default("development"),
  API_HOST: z.string().default("127.0.0.1"),
  TRUST_PROXY_LOOPBACK: bool.default(false),
  API_PORT: z.coerce.number().int().min(1).max(65535).default(4100),
  WEB_ORIGIN: z.url().default("http://localhost:3100"),
  DATABASE_URL: z.string().startsWith("postgresql://"),
  REDIS_URL: z.string().startsWith("redis://"),
  SESSION_DAYS: z.coerce.number().int().min(1).max(30).default(14),
  COOKIE_SECURE: bool.default(false),
  UPLOAD_DIR: z.string().default("./uploads"),
  MAX_UPLOAD_MB: z.coerce.number().int().min(1).max(25).default(10),
  ALLOW_PRODUCTION_UPLOADS: bool.default(false),
  REQUIRE_E2EE: bool.default(false),
  CAPTCHA_REQUIRED: bool.default(false),
  TURNSTILE_SECRET: z.string().default(""),
  TURNSTILE_SITE_KEY: z.string().default(""),
  TURNSTILE_HOSTNAME: z.string().default("localhost"),
});
export const config = schema.parse(process.env);
if (
  config.NODE_ENV === "production" &&
  (!config.COOKIE_SECURE ||
    !config.WEB_ORIGIN.startsWith("https://") ||
    !config.CAPTCHA_REQUIRED ||
    !config.TURNSTILE_SECRET ||
    !config.TURNSTILE_SITE_KEY)
)
  throw new Error(
    "Production requires HTTPS, secure cookies and configured CAPTCHA",
  );
export const cookieName = config.COOKIE_SECURE
  ? "__Host-nightspace"
  : "nightspace";
