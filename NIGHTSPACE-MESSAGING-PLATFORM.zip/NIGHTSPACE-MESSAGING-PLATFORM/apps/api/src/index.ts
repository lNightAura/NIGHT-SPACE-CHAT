import { createServer } from "node:http";
import { createApp } from "./app.js";
import { config } from "./config.js";
import { db, redis } from "./db.js";
import { setupRealtime } from "./realtime.js";
await db.$connect();
await redis.connect();
const server = createServer(createApp());
server.requestTimeout = 15000;
server.headersTimeout = 10000;
server.maxRequestsPerSocket = 1000;
const closeRealtime = await setupRealtime(server);
server.listen(config.API_PORT, config.API_HOST, () =>
  console.log(
    JSON.stringify({ event: "listening", port: config.API_PORT, e2ee: false }),
  ),
);
let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  const timeout = setTimeout(() => process.exit(1), 10000).unref();
  await closeRealtime();
  await new Promise<void>((resolve) => server.close(() => resolve()));
  await db.$disconnect();
  await redis.quit();
  clearTimeout(timeout);
  process.exit(0);
}
process.on("SIGTERM", stop);
process.on("SIGINT", stop);
