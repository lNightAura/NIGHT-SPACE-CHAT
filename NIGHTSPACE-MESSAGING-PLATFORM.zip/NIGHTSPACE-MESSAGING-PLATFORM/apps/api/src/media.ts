import { Router } from "express";
import multer from "multer";
import { randomUUID } from "node:crypto";
import { mkdir, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
import { db } from "./db.js";
import { config } from "./config.js";
import { actor, membership, canSend, id, rate } from "./security.js";
import { HttpError } from "./errors.js";
export function detectMime(b: Buffer) {
  if (b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])))
    return "image/png";
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return "image/jpeg";
  if (b.subarray(0, 5).toString() === "%PDF-") return "application/pdf";
  if (b.subarray(0, 4).toString() === "OggS") return "audio/ogg";
  if (b.subarray(4, 8).toString() === "ftyp") return "video/mp4";
  if (
    b.subarray(0, 4).toString() === "RIFF" &&
    b.subarray(8, 12).toString() === "WEBP"
  )
    return "image/webp";
  return null;
}
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: config.MAX_UPLOAD_MB * 1024 * 1024,
    files: 1,
    fields: 0,
    parts: 1,
  },
});
export const media = Router();
media.post(
  "/conversations/:id/attachments",
  rate("upload", 10),
  async (req, _res, next) => {
    if (config.REQUIRE_E2EE)
      throw new HttpError(503, "Encrypted uploads unavailable");
    if (config.NODE_ENV === "production" && !config.ALLOW_PRODUCTION_UPLOADS)
      throw new HttpError(
        503,
        "Production uploads require operator approval and scanning controls",
      );
    await canSend(actor(req).userId, id(req.params.id));
    next();
  },
  upload.single("file"),
  async (req, res) => {
    const userId = actor(req).userId,
      conversationId = id(req.params.id);
    if (!req.file) throw new HttpError(400, "Select a file");
    const mime = detectMime(req.file.buffer);
    if (!mime || mime !== req.file.mimetype)
      throw new HttpError(400, "Unsupported or mismatched file type");
    const filename =
      path
        .basename(req.file.originalname)
        .replace(/[^\p{L}\p{N}._ -]/gu, "_")
        .slice(0, 120) || "attachment";
    const diskKey = randomUUID(),
      directory = path.resolve(config.UPLOAD_DIR);
    await mkdir(directory, { recursive: true });
    await writeFile(path.join(directory, diskKey), req.file.buffer, {
      flag: "wx",
      mode: 0o600,
    });
    try {
      const f = await db.attachment.create({
        data: {
          ownerId: userId,
          conversationId,
          filename,
          diskKey,
          mime,
          size: req.file.size,
        },
        select: { id: true, filename: true, mime: true, size: true },
      });
      res.status(201).json(f);
    } catch (e) {
      await unlink(path.join(directory, diskKey)).catch(() => {});
      throw e;
    }
  },
);
media.get("/attachments/:id", rate("download", 120), async (req, res) => {
  const f = await db.attachment.findUnique({
    where: { id: id(req.params.id) },
  });
  if (!f) throw new HttpError(404, "File not found");
  await membership(actor(req).userId, f.conversationId);
  res.setHeader("Content-Type", f.mime);
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("Content-Security-Policy", "default-src 'none'; sandbox");
  res.download(
    path.join(path.resolve(config.UPLOAD_DIR), f.diskKey),
    f.filename,
  );
});
