# NIGHTSPACE project status — 0.1.0 development milestone

**Delivery date: 2026-11-07. Not production-ready. Not completion of the whole original specification.**

## Phase checkpoint

- Phase 1 architecture/foundation: delivered (real monorepo, environment checks, PostgreSQL schema, two SQL migrations, Redis, local Compose, lockfile).
- Phase 2 authentication/core messaging: working tested subset delivered. Media is a private attachment foundation, not a fully featured gallery/voice/media suite.
- Phase 3 security/privacy: actual baseline controls and regression tests delivered; E2EE, MFA/device verification, account recovery and external review remain unfinished.
- Phase 4 voice: **not implemented**; design and non-active TURN configuration template only.
- Phase 5 premium UI: all 13 semantic theme palettes, gallery, accent preview/save/reset, responsive desktop/mobile and reduced motion delivered. Full custom/per-chat theme editor and exhaustive accessibility audit are not complete.
- Phase 6 advanced features: basic groups, saved messages, per-user folder metadata only. Remaining features deferred.
- Phase 7 operations: RBAC metrics/reports API, liveness/readiness, production builds, tests, documentation and packaging delivered. Full admin dashboard/monitoring/deployment certification absent.

## Implemented source

Accounts: register/login/logout/all-device logout, Argon2id hashes, opaque HttpOnly cookie sessions, DB expiry, revocation including active sockets, password change reauthentication, editable display name/bio, account JSON export and deletion.
Messaging: direct/group/saved chat creation, durable text and Unicode/RTL, replies/edit/delete-me/delete-everyone/reactions/copy/search/details, transient send/failure/retry UI, idempotent client IDs, stable cursor history, unread/read/delivered metadata, server-authorized Socket.IO fanout, typing privacy, reconnect/refetch and multi-device message updates. Personal pin/archive/mute/folder metadata exists. Mute does not suppress nonexistent push notifications.
Files: bounded multipart, allowlisted magic-byte/MIME checks, random private storage, membership-authorized download, progress/drag-drop UI. No public storage mount. Production upload opt-in defaults false; no AV engine or encrypted media.
UI: Next/React/TS/Tailwind/Motion, Luxury Cream default, 13 complete semantic palettes, per-user settings sync, SSR theme cookie, accent contrast check, separate mobile screens, safe-area composer, dialogs/focus handling/empty/error/404/skeleton states.
Security/operations: Origin CSRF defense, parameterized queries, strict input validation, secure headers, Redis rate counters, Turnstile server verifier and replay cache, admin RBAC counts/report APIs, action-only audits, health/readiness, graceful shutdown and documented deployment isolation.

## Tested / verification evidence

The final executed commands, exact counts, exit statuses and logs are in `docs/TEST_RESULTS.md` and `docs/evidence/`. Earlier failures (type/token test assumption, npm resolver, mocked CAPTCHA Response reuse, missing browser libraries, socket trailing slash proxy, message-menu clipping and asynchronous privacy toggle) were diagnosed and fixed, not hidden. Current tests are not evidence that every requested feature exists.

## E2EE status

**Not implemented.** Server-readable messages/files/metadata; no device encryption private keys. Visible disclosure in auth/chat/security UI. `REQUIRE_E2EE=true` fails sending/upload closed, but existing data remains readable. `docs/E2EE_DESIGN.md` is a proposal, NOT an encryption implementation.

## Voice status

**Not implemented or verified.** No recording, signaling, peer connections, call history, TURN credentials or audio controls. Microphone/camera denied by current Permissions-Policy. `docs/VOICE_DESIGN.md` and coturn template are preparation only.

## CAPTCHA status

Backend verification, action/hostname checking, replay guard, timeout and production configuration guard are implemented. Browser widget exists. Tests mock provider responses; real keys, external network verification and actual challenge completion were NOT tested. Development bypass is explicit. Production refuses missing configuration.

## Not implemented / partial features

Recovery, avatars/cropping, encryption device identities/trust/rekeying, TOTP/recovery codes/passkeys, online/last seen, privacy PIN lock/lockdown, push/desktop/audio notifications and security alerts, account retention/disappearing messages, message forwarding/message pin, scheduling/jobs, polls, stories, translation, link previews, media gallery/inline playback, voice recording/calls, full group invitation/permission UI, full custom/per-chat themes, complete admin dashboard/moderation/user-management and feature flags, adaptive abuse analytics, distributed presence/load-tested scaling. See the section-by-section `docs/REQUIREMENTS_MATRIX.md`; original requirements are preserved.

## Known limitations / risks

- No independent security audit or production approval; do not use for confidential messages.
- Basic signature checks are not malware scanning/complete format parsing. Orphan/unreferenced file cleanup is manual and deletion does not erase backups; production file upload disabled by default.
- Conversation list lacks cursor pagination and unread queries are per conversation. Contains-search, timestamp read watermark and current message-window refresh need scale/edge-case review.
- Pending sends/replies/drafts are memory-only, lost on navigation/reload; offline page startup is not supported. Loading an earlier history page then a live refresh can collapse view back to the newest page; server history is not deleted.
- Fixed-window rate counters are not adaptive. Proxy address can aggregate clients; deployment guidance must be followed. HTTP counters support explicit loopback proxy trust; socket IP counters still use immediate peer, with additional account checks.
- Socket delivery/outbox is not durable; periodic HTTP sync and idempotent REST retries are recovery mechanisms, not exactly-once events.
- CSP allows inline hydration/styles; nonce hardening/accessibility audit pending.
- Windows instructions prepared, not run on Windows. No Safari/Firefox/device farm, live Turnstile, WAF/TURN, production HTTPS, load/chaos/security penetration or off-host restore verification.
- Dependency patches pin dev-tool transitive deepmerge-ts 8.0.2 and minimatch 11.0.5. Compatibility is covered by schema generation/migration/lint/build/tests, not a universal guarantee; reassess on dependency upgrades.

## External configuration still needed

Dedicated PostgreSQL/Redis, exact public Origin, HTTPS/Nginx, domain/certificates, private storage, encrypted external backups, real Turnstile hostname/site/secret keys, WAF/CDN/origin policy and operational monitoring. TURN is future work, not a missing key that would enable calls. No VPS/SSH/dashboard was accessed; no production secrets requested or included.

## Files created / modified

`FILE_MANIFEST.json` records every packaged file with size/hash (self-entry intentionally omitted). Sources under apps/api, apps/web, packages/shared; relational schema/two migrations/seed; tests and scripts; docs; infrastructure examples; environment template/lockfile. Build caches/node_modules/local .env/test uploads/traces excluded intentionally. Actual test screenshots are included under docs/screenshots.

## Exact next action

Unpack the archive, follow README Windows setup, validate locally with two browser profiles. Before adding more functionality, run an isolated security review of the delivered core. Then select and validate a maintained audited E2EE protocol library in a dedicated branch, implement device/key/attachment lifecycle and test vectors. Only after this boundary is defined implement the separate WebRTC call state machine and short-lived TURN infrastructure. Do not restart or replace the existing working core. Track remaining requirements in the preserved coverage matrix and add tests with each phase.
