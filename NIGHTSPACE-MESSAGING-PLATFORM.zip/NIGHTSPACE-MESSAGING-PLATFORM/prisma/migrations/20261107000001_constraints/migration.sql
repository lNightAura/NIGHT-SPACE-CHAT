-- Defense in depth: validated application enums also constrained in PostgreSQL.
ALTER TABLE "User" ADD CONSTRAINT "User_role_check" CHECK ("role" IN ('USER', 'ADMIN'));
ALTER TABLE "Member" ADD CONSTRAINT "Member_role_check" CHECK ("role" IN ('ADMIN', 'MEMBER'));
ALTER TABLE "Conversation" ADD CONSTRAINT "Conversation_kind_check" CHECK ("kind" IN ('DIRECT', 'GROUP', 'SAVED'));
ALTER TABLE "Message" ADD CONSTRAINT "Message_body_size_check" CHECK (char_length("body") <= 16000);
ALTER TABLE "Attachment" ADD CONSTRAINT "Attachment_positive_size_check" CHECK ("size" > 0);
ALTER TABLE "Block" ADD CONSTRAINT "Block_no_self_check" CHECK ("userId" <> "targetId");
