import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import * as argon2 from 'argon2';
const db=new PrismaClient();
if(!process.env.SEED_PASSWORD||process.env.SEED_PASSWORD.length<12)throw new Error('Set SEED_PASSWORD with at least 12 characters');
const passwordHash=await argon2.hash(process.env.SEED_PASSWORD,{type:argon2.argon2id,memoryCost:19456,timeCost:2,parallelism:1});
for(const [username,displayName] of [['aurora','Aurora Lane'],['atlas','Atlas Reed']])await db.user.upsert({where:{username},create:{username,displayName,passwordHash},update:{}});
console.log('Optional demo users seeded; existing passwords unchanged. No administrator was created.');await db.$disconnect();
