# NIGHTSPACE

### A little closer.

A real multi-file messaging monorepo. **Version 0.1.0 is a tested development milestone, NOT the finished master specification and NOT approved for production use.**

> **No E2EE. No audio calls.** The database and private file store hold server-readable content. The UI discloses this. If `REQUIRE_E2EE=true`, message and attachment creation fail closed. Never use this release for confidential communications.

## What runs

Next.js 16 / React 19 / TypeScript / Tailwind 4 / Framer Motion; structured Express 5 / Socket.IO; PostgreSQL 16 / Prisma 6; Redis 7. Tested in Linux with Node 22.23.4. Windows 11 instructions below are prepared but were not executed on Windows.

Accounts and revocable HTTP-only sessions; profiles; direct, basic group and saved-message conversations; persistent Unicode text; replies, editing, deletion, reactions, delivery receipts; cursor history and retry deduplication; real-time synchronization; protected attachment foundation; all 13 semantic themes; responsive desktop/mobile screens; theme/profile/security settings. No daily/monthly message credits, subscriptions or history truncation. Short-window anti-abuse throttles and file-size protections apply.

## Exact Windows 11 / PowerShell setup

Prerequisites: Node.js 22 LTS with npm, Docker Desktop in Linux-container mode, Git optional. PostgreSQL/Redis need not be installed separately when using Compose. Do not run integration tests against your development or production data.

```powershell
Expand-Archive .\NIGHTSPACE-MESSAGING-PLATFORM.zip -DestinationPath .\nightspace-source
Set-Location .\nightspace-source\NIGHTSPACE-MESSAGING-PLATFORM
Copy-Item .env.example .env
# Edit BOTH POSTGRES_PASSWORD and the password in DATABASE_URL to the SAME local-only value.
# Use a password with letters/numbers or URL-encode URL-reserved characters.
notepad .env
# Keep NODE_ENV=development, CAPTCHA_REQUIRED=false, COOKIE_SECURE=false locally.
# Compose refuses to start if POSTGRES_PASSWORD is not provided.
docker compose up -d
npm ci
npm run db:generate
npm run db:migrate
npm run build -w @nightspace/shared
npm run env:check
npm run dev
```

Open **http://localhost:3100**, not 127.0.0.1 (the configured Origin must match). Create two accounts in separate browser profiles to test direct messaging. The second account's exact username starts a conversation. The API is loopback-only on 4100; Compose uses local ports 55432 and 56379. Confirm they are free before starting. `npm ci` follows the included lockfile and `.npmrc` resolver compatibility setting. The initial npm 10 resolver crashed on optional peer dependency resolution; `legacy-peer-deps=true` is explicit, with final lockfile builds tested.

Optional sample accounts, no default password:

```powershell
$env:SEED_PASSWORD = "choose-your-own-local-passphrase-at-least-12-characters"
npm run db:seed
Remove-Item Env:SEED_PASSWORD
```

`aurora` and `atlas` are created only if missing; seeding does not reset existing accounts and creates no admin.

## Verification

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm audit --omit=dev
```

`npm run typecheck` generates Next route types and builds shared contracts before checking application/test/tool sources.

For integration/browser tests use a separate `nightspace_test` database and **Redis database 15**, then set `NIGHTSPACE_TEST_ALLOW_RESET=true` in your test shell. The integration suite deletes users/conversations; browser tests clear Redis DB 15. See **docs/TESTING.md** for exact commands and safeguards. Browser tests start their own API and optimized Next server; stop `npm run dev` first.

## Layout

```text
apps/api/src/         auth, authorization, conversations, messages, private files, sockets
apps/web/             Next App Router, components, tokens-driven responsive UI
packages/shared/      validation, wire types, all 13 semantic palettes
prisma/               relational schema, SQL migrations, optional seed
infrastructure/       isolated Nginx, PM2, PostgreSQL and coturn reference files
scripts/              environment checks, upload maintenance, packaging and backup scripts
tests/                unit, real-service integration, desktop/mobile Chromium workflows
docs/                 architecture, API, limitations, matrix, original requirements, evidence
```

## First places to read

`PROJECT_STATUS.md` — exact implemented/partial/deferred boundary and next steps.
`SECURITY.md` — threats and remaining gaps; no ASVS certification implied.
`DEPLOYMENT.md` — operator-only, non-disruptive Freestyle VPS preparation. **No VPS was accessed.**
`docs/TEST_RESULTS.md` — actual validation results; not claims of complete security.
`FILE_MANIFEST.json` — paths, sizes and SHA-256 hashes; self-entry intentionally omitted.

## Required configuration

At minimum `DATABASE_URL`, `REDIS_URL` and exact `WEB_ORIGIN`. `.env.example` lists every application variable. Production additionally requires HTTPS, `COOKIE_SECURE=true`, `CAPTCHA_REQUIRED=true`, Turnstile secret/site key/hostname. `ALLOW_PRODUCTION_UPLOADS` defaults false pending external malware scanning controls. TURN is not integrated, so no TURN secrets belong in this application yet.

## Packaging

`python scripts/package.py` works with Python 3 on Windows; `python3 scripts/package.py` on Linux. It excludes dependencies, generated builds, local environments, test traces and uploads; validates required files and manifest checksums; creates `NIGHTSPACE-MESSAGING-PLATFORM.zip` beside the source directory. Dependencies are recreated using `npm ci`, followed by Prisma generation and build. The included lockfile pins actual dependencies.

No public demo, deployment, default admin credentials, paid message limits or pretend encryption is included. See the requirements matrix rather than assuming every requested feature is finished.
