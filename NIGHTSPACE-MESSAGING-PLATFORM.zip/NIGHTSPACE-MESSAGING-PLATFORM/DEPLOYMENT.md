# Manual Freestyle VPS deployment preparation

## IMPORTANT: do not disrupt existing apps or Telegram bots

**Nothing has been deployed or connected to your VPS.** This is documentation only. Do not overwrite, stop, restart, reconfigure or remove existing applications, services, databases, ports, domains, PM2 processes, firewall rules or Nginx sites. Never run `pm2 stop all`, `pm2 delete all`, `docker compose down -v`, broad firewall reset commands, or replace the global Nginx configuration. Do not assume resources or ports are available. Use a separate unprivileged system user, project directory, database, Redis namespace/database, storage directory, PM2 names and Nginx site. Have an operator review every command and test in isolated staging first.

**This release is not approved for public production.** E2EE/calls/recovery and several hardening features are incomplete. The following is preparation for a future reviewed release or an isolated internal trial.

## 1. Inventory before making changes

Operator checks existing listeners (`ss -ltnp`), memory/disk (`free -h`, `df -h`), Nginx sites (`nginx -T`, privately), PostgreSQL/Redis services, PM2 process inventory, active Docker ports and existing backup procedures. These commands are suggestions for the operator; none was run against your VPS. If 3100/4100/55432/56379 conflict, choose different dedicated ports and update the Next start command, `API_PORT`, `API_INTERNAL_URL`, `WEB_ORIGIN`, Nginx and PM2 examples consistently. Do not change an existing service's port to make room.

## 2. Isolated prerequisites

Node 22 LTS + npm, PostgreSQL 16, Redis 7 and Nginx with WebSocket proxying. PM2 is optional but examples supplied. The operator installs these without replacing existing incompatible runtimes (use per-user runtime version management). Host capacity must be measured: do not assume that the VPS can fit the database, Redis, other bots, and Next build memory at once. Build elsewhere if necessary, then copy reviewed artifacts/lockfile. Do not run load tests against unrelated hosted services.

Create a dedicated PostgreSQL login/database using interactive operator-selected credentials, least privileges and a bounded connection URL. Do not grant superuser/createdb to the app account. `prisma migrate deploy` needs schema DDL rights; use a separate migration role in mature deployments. Configure database `statement_timeout` and `idle_in_transaction_session_timeout` per dedicated role (see `infrastructure/postgres-settings.sql`), not globally for other applications.

Redis must not be public. Choose an isolated instance or reviewed existing logical DB/ACL; Redis databases are **not security boundaries**. Supply password/ACL in the REDIS_URL via protected environment, not committed configuration. The shipped parser accepts `redis://`; terminating Redis TLS securely requires code/config work before using `rediss://`. Never use test DB 15 on shared production Redis. Avoid `FLUSHDB`/`FLUSHALL`.

## 3. Environment and build

Use `.env.example` as inventory, not ready-made production settings. Protect `.env` with owner-only permissions. In the isolated app directory:

```bash
npm ci
npm run db:generate
npm run build -w @nightspace/shared
npm run env:check
npm run lint
npm run typecheck
npm test
npm run db:migrate
npm run build
npm audit --omit=dev
```

Set `NODE_ENV=production`, `COOKIE_SECURE=true`, `WEB_ORIGIN=https://chat.your-domain.example`, exact CAPTCHA hostname, `CAPTCHA_REQUIRED=true` and real operator-provided Turnstile keys. API binds loopback; `API_PORT=4100`, `API_INTERNAL_URL=http://127.0.0.1:4100` are examples only. `UPLOAD_DIR` must be an absolute, private, non-webroot path writable only by the app user; `MAX_UPLOAD_MB=10`; keep `ALLOW_PRODUCTION_UPLOADS=false` until external scanning/quarantine policy is reviewed. No production credentials are included.

Set `REQUIRE_E2EE=true` to disable server-readable sending if encrypted-only operation is your policy. This makes this milestone unsuitable for normal messaging until E2EE is implemented; it does not magically encrypt data. If you intentionally permit server-readable internal testing, keep the UI disclosure and control the audience.

For Next, build-time `API_INTERNAL_URL` determines rewrite destination. Set it before building. See `.env.example` for all variables. Root `.env` is loaded explicitly by API and Next configuration; PM2 environment takes precedence. Optional `TRUST_PROXY_LOOPBACK=true` is appropriate only when the app listens exclusively on loopback and Nginx overwrites forwarding headers. Review IPv4/IPv6 paths. No wildcard proxy trust is allowed.

## 4. PM2 / startup

Copy and EDIT `infrastructure/ecosystem.config.cjs`; set isolated working directory and reviewed ports. From that directory:

```bash
pm2 start infrastructure/ecosystem.config.cjs --env production --only nightspace-api,nightspace-web
pm2 status
```

No `pm2 save`, global startup-service modifications or restarts of other processes are automated. The operator should integrate this into existing PM2/service management deliberately. Production uses one API process and one Next process initially. `npm run start -w @nightspace/api` / `npm run start -w @nightspace/web` are direct alternatives. Native Argon2 binaries require a supported platform or native build toolchain.

## 5. Nginx and HTTPS

`infrastructure/nginx.conf.example` is a **new isolated server block**, not a replacement for nginx.conf. Replace hostname/certificate paths; provision a certificate using your established process, then `nginx -t` before an operator-approved reload. Add the site without changing unrelated blocks. Restrict API/storage/DB/Redis to loopback/private access. Never expose uploads as a public alias. Proxy `/api/` and `/socket.io` to the API; all other paths to Next. Cookie host, Origin and public domain must agree. Avoid trailing-slash redirects on the socket endpoint; a browser WebSocket does not follow them in this flow. Preserve upgrade headers and sufficient read timeout. The Next development rewrite has the same path behavior tested in Chromium.

The example does not include HSTS preload because it could affect unrelated subdomains. Add a reviewed HSTS policy only after valid TLS and domain ownership checks. Cert renewal and monitoring are operator responsibilities.

## 6. CDN/WAF and origin protection

Use CDN proxy + strict end-to-end TLS for the specific chat hostname if desired. Apply bounded login/register/API/upload rules; do not cache authenticated pages, API responses or private media. Support WebSockets; do not require CAPTCHA on every message. Turnstile host/action must match server validation. Review body/upload limits and socket idle timeout. Without a provider API integration, admin metrics correctly report WAF status as not integrated.

Restrict origin ingress to CDN IP ranges **only after reviewing existing applications on the same IP**. A host-wide change can break bots, other websites or your management access. Prefer scoped rules or a separate origin/port arrangement, preserve authorized management access, and test rollback. If using real-client-IP headers, restrict trusted ranges to maintained CDN ranges in Nginx; overwrite downstream X-Forwarded-For with that validated client IP. Do not accept arbitrary client-supplied forwarding headers. The code does not automatically download or trust CDN IP ranges. External provider/ISP protections, not this app, handle volumetric DDoS.

## 7. Voice / TURN

Voice is **not implemented** and no credentials are generated or consumed by the app. `infrastructure/turnserver.conf.example` is a non-active planning template. Before future calling: deploy isolated coturn with reviewed UDP/TCP relay port ranges, TLS, realm/domain, short-lived HMAC credentials issued by an authenticated rate-limited backend and bandwidth caps. Audit coexistence with other VPS traffic. Test NAT/mobile/browser permissions, reject/missed/end states and reconnection. Never expose a static TURN secret to clients or claim calls work from this template.

## 8. Backups and restore

See `docs/BACKUP_RESTORE.md` and `scripts/backup.ps1`. Back up PostgreSQL, private uploads and protected environment separately to encrypted access-controlled off-host storage. Redis is transient for this milestone. Test restoration into a NEW isolated DB/storage directory before any cutover. Backups retain server-readable content; storage encryption is an external requirement. Retention is operator policy, not automatic.

## 9. Health / logs / operational safety

API `/api/health` is liveness; `/api/ready` checks DB/Redis and returns failure on outage. These endpoints should be monitored through controlled routes. Do not log request bodies, cookies, auth headers, CAPTCHA tokens, private filenames or message content in Nginx, PM2 or monitoring. Use bounded retention and log rotation scoped only to NIGHTSPACE files. Application audit events are action/actor only. No error monitoring vendor is configured. Admin role is assigned out of band by a trusted operator; registration never accepts role. Admin API exposes counts/reports, not messages.

## 10. Rollback and troubleshooting

Use versioned releases, immutable lockfile and a known working backup. A DB migration may not be reversible by swapping code: assess schema compatibility before cutover; do not run destructive reset or blind `db push`. Repoint only NIGHTSPACE processes to the previous tested release; do not change other PM2 apps. Restore data only under a planned maintenance procedure with verified encrypted backups and user-impact communication.

- 401: cookie host/Secure/expiry; inspect names, not token values. Local HTTP uses non-Secure cookie by design.
- 403 Origin: `WEB_ORIGIN` must match the browser's exact scheme/host/port, not internal API URL.
- 429: transient abuse throttle. Fix trusted-proxy attribution; do not remove anti-abuse controls or invent message subscriptions.
- 503: Redis/DB outage, CAPTCHA timeout, require-E2EE guard, or uploads intentionally disabled. Use health endpoints and internal diagnostics, never expose stacks.
- Socket reconnect: upgrade headers, no `/socket.io` trailing slash redirects, hostname/cookie, exact Origin, Redis adapter. HTTP refetch is the recovery path.
- Failed upload: byte/type mismatch, size cap, external scanning gate, directory permissions. Do not make storage world-readable to work around it.

No remote command, SSH session, hosting dashboard access or VPS deployment was performed as part of this delivery.
