import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
const result = spawnSync(
  process.platform === "win32" ? "python" : "python3",
  [fileURLToPath(new URL("./package.py", import.meta.url))],
  { stdio: "inherit" },
);
if (result.error) {
  console.error("Packaging requires Python 3 on PATH.");
  process.exit(1);
}
process.exit(result.status ?? 1);
