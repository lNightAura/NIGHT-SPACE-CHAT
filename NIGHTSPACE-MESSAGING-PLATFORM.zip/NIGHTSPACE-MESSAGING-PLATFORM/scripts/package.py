"""Create a checked source archive. Run from any current directory with Python 3."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={'node_modules','.next','dist','.git','test-results','playwright-report','uploads','__pycache__'}
def included(p):
    rel=p.relative_to(ROOT)
    if any(part in EXCLUDED for part in rel.parts): return False
    if p.name.startswith('.env') and p.name!='.env.example': return False
    if p.suffix in {'.log','.tsbuildinfo','.zip'}: return False
    return p.is_file()
required=['README.md','PROJECT_STATUS.md','SECURITY.md','DEPLOYMENT.md','.env.example','package-lock.json','prisma/schema.prisma','prisma/migrations/20261107000000_initial/migration.sql','apps/api/src/index.ts','apps/web/app/page.tsx','docs/TEST_RESULTS.md']
for name in required:
    if not (ROOT/name).is_file(): raise RuntimeError('Missing required file: '+name)
files=sorted((p for p in ROOT.rglob('*') if included(p) and p.name!='FILE_MANIFEST.json'),key=lambda p:p.as_posix())
manifest={'format':1,'scope':'Current development milestone only; excludes generated dependencies/builds/secrets. Manifest self-entry omitted.','files':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
mp=ROOT/'FILE_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');files.append(mp)
archive=ROOT.parent/'NIGHTSPACE-MESSAGING-PLATFORM.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files: z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in manifest['files']:
        data=z.read(ROOT.name+'/'+entry['path'])
        assert hashlib.sha256(data).hexdigest()==entry['sha256'],entry['path']
    assert not any('/node_modules/' in name or name.endswith('/.env') for name in z.namelist())
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
