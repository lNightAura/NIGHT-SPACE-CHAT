param(
  [Parameter(Mandatory=$true)][string]$DatabaseHost,
  [Parameter(Mandatory=$true)][int]$DatabasePort,
  [Parameter(Mandatory=$true)][string]$DatabaseName,
  [Parameter(Mandatory=$true)][string]$DatabaseUser,
  [Parameter(Mandatory=$true)][string]$UploadDirectory,
  [Parameter(Mandatory=$true)][string]$Destination
)
$ErrorActionPreference = 'Stop'
# pg_dump prompts or uses PGPASSFILE. Do not include a password in arguments.
# Destination must be private. Encrypt both files before off-host transfer.
New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$dump = Join-Path $Destination "nightspace-$stamp.dump"
& pg_dump --host=$DatabaseHost --port=$DatabasePort --username=$DatabaseUser --dbname=$DatabaseName --format=custom --no-owner --no-acl --file=$dump
if ($LASTEXITCODE -ne 0) { throw 'Database backup failed' }
if (!(Test-Path $dump) -or (Get-Item $dump).Length -eq 0) { throw 'Backup is empty' }
if (Test-Path $UploadDirectory) {
  # Compress-Archive may have platform size limits; use your backup system for large stores.
  Compress-Archive -Path (Join-Path $UploadDirectory '*') -DestinationPath (Join-Path $Destination "nightspace-uploads-$stamp.zip")
}
Get-FileHash -Algorithm SHA256 $dump
Write-Output 'Backup files written. Encryption and a staging restore drill are still required.'
