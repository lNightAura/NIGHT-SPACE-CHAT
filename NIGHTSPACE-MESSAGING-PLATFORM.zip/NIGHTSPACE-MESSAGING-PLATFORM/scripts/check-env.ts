import { config } from "../apps/api/src/config.js";
console.log({
  valid: true,
  mode: config.NODE_ENV,
  e2ee: false,
  captcha: config.CAPTCHA_REQUIRED ? "required" : "explicit development bypass",
});
