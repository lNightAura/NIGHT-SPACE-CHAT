import { db } from "../apps/api/src/db.js";
import { config } from "../apps/api/src/config.js";
import path from "node:path";
import { unlink } from "node:fs/promises";
const apply = process.argv.includes("--apply");
const cutoff = new Date(Date.now() - 86400000);
const candidates = await db.attachment.findMany({
  where: { createdAt: { lt: cutoff }, messages: { none: {} } },
  select: { id: true, diskKey: true },
  take: 500,
});
let removed = 0;
if (apply)
  for (const entry of candidates) {
    const result = await db.attachment.deleteMany({
      where: { id: entry.id, messages: { none: {} } },
    });
    if (result.count) {
      await unlink(
        path.join(path.resolve(config.UPLOAD_DIR), entry.diskKey),
      ).catch(() => {});
      removed++;
    }
  }
console.log({
  mode: apply ? "apply" : "dry-run",
  eligible: candidates.length,
  removed,
  batchLimit: 500,
});
await db.$disconnect();
