# Security and privacy — read before use

## Release classification

Development milestone only. Successful tests/builds are not a security audit, ASVS Level 2 compliance, DDoS protection guarantee or production certification. Do not entrust sensitive content to this version.

## Actual controls

- Argon2id (`memoryCost=19456 KiB`, time 2, parallelism 1), 12–128 character registration passwords. Password hashes never leave API account selections.
- 32-byte random session token; SHA-256 digest only in DB. HttpOnly, SameSite=Lax, bounded expiry; production Secure + `__Host-` cookie. No auth tokens in browser storage. Login rotates the existing browser session, password change revokes all sessions and issues a fresh one.
- Exact `WEB_ORIGIN` on browser mutations, including login/logout/registration; missing Origin is rejected. This is an Origin-based CSRF defense, not a hidden form token. No permissive credentialed CORS. WebSocket requires Origin and a live session; reconnect and each event revalidate identity. Revocation disconnects active device rooms.
- Server membership checks on message history, writes, edits, replies, attachments and socket events. Server derives recipients. Canonical direct keys and sender/clientId constraint stop duplicated conversations/messages. Client identity fields are rejected.
- Strict Zod schemas, Prisma parameter binding, React text rendering, secure headers, no public upload mount, no auto-fetched link previews (SSRF surface intentionally absent).
- Atomic Redis IP/endpoint and account counters. Short windows are anti-abuse, not paid quotas. Redis failure fails rate-dependent operations closed.
- Backend Turnstile verification checks success/hostname/action; Redis replay guard; timeouts. Explicit development bypass, production startup refuses missing keys. External provider was mocked in tests: live CAPTCHA behavior is **not verified**.
- Upload byte/type allowlists, size bounds, randomized storage names, private membership-gated attachment responses with no-store, attachment disposition, nosniff and sandbox CSP. Production upload opt-in is false by default.
- No passwords, tokens, message content, private keys or raw IPs in application logs/audit records. Audit stores actor ID and action, not content. Role-gated admin metrics/reports are not a moderation dashboard.

## Critical limitations

**No E2EE**: message bodies, filenames and file contents are readable by the server/DB/storage operator. No encryption private keys exist. Local development HTTP is not transport-encrypted; production must use HTTPS. No message-at-rest encryption is supplied by the app. Use encrypted volumes/backups as external controls. `REQUIRE_E2EE=true` prevents writes; it does not add encryption or conceal already-stored history.

No device key lifecycle, forward secrecy, encrypted backups, TOTP, recovery codes, passkeys, account recovery or application privacy lock. No voice calls, recording or TURN credential endpoints. These are NOT implied by UI icons or schema placeholders.

Byte signatures do not prove a file harmless or fully validate its format. Polyglots and malicious PDFs/media remain possible. Downloads are forced as attachments; never render them unsandboxed. External scanning/quarantine and deeper format parsing must precede public upload enablement. Media deletion/retention is partial: unlinking a message does not guarantee immediate removal of unreferenced blobs. `prune-uploads.ts` is a manual dry-run/apply maintenance tool for old unreferenced uploads, not a running background service. Backups can retain deleted data until their retention deadline.

Rate limiting is fixed-window, not adaptive spam/bot analytics, permanent bans, or volumetric DDoS defense. Reverse-proxy IP attribution must be configured correctly; otherwise all clients share the proxy IP throttle. WebSocket IP counters still use the immediate peer address; account counters apply as well. Multi-instance Redis event fanout exists, but cluster/load testing, socket connection quotas across workers, Redis authentication/TLS configuration and shared attachment storage remain operator work.

CSP permits inline scripts/styles for Next hydration; development additionally allows eval. Nonce/hash CSP hardening remains future work. Mixed-content connect-src is broader than ideal; production Nginx TLS and same-origin proxy are mandatory. No inline HTML or external link preview execution is implemented. `Permissions-Policy` disables camera/microphone because calling is not implemented.

Exports stream messages in bounded batches but are not a transactional snapshot and include authored messages only, not all conversation history or binary attachments. Conversation listing is not paginated; unread counts use per-chat queries, and text search uses case-insensitive contains. These need scale work, benchmarks and indexes before large deployment. Read receipt watermark is a timestamp rather than a per-message read ledger. Drafts/pending retries are in component memory and may be lost on reload or changing chats.

Session lifetime is fixed, no sliding refresh. Fixed session expiration timer and Redis pub/sub revocations are implemented, but crash/restart and backpressure chaos testing is pending. Sensitive-operation races around concurrent password changes/deletions need a dedicated security review.

## Safe configuration

Use loopback-only services, least-privilege Postgres role, Redis private network and credentials/ACLs, bounded DB connections, TLS reverse proxy, encrypted backups, host patching, WAF/CDN and origin restrictions. Never trust arbitrary forwarded headers. Only enable `TRUST_PROXY_LOOPBACK=true` with loopback-only API and an audited proxy that overwrites X-Forwarded-For. Never run reset-enabled tests on production.

## Reporting / review

No fabricated security contact address is provided. Use your private development team's existing vulnerability channel. Do not publish secrets or private message content in issues. Before release: commission access-control, session/CSRF, upload, proxy, dependency, privacy and operational reviews. Preserve minimum necessary metadata when investigating reports. No administrative endpoint lists message bodies or encryption keys; the server-readable storage itself is not confidential from an infrastructure administrator.
