import { z } from "zod";
export const username = z
  .string()
  .min(3)
  .max(32)
  .regex(/^[a-zA-Z0-9_]+$/)
  .transform((v) => v.toLowerCase());
export const password = z.string().min(12).max(128);
export const registration = z
  .object({
    username,
    displayName: z.string().trim().min(1).max(80),
    password,
    captchaToken: z.string().max(4096).optional(),
  })
  .strict();
export const login = z
  .object({
    username: z
      .string()
      .max(64)
      .transform((v) => v.toLowerCase()),
    password: z.string().max(128),
    captchaToken: z.string().max(4096).optional(),
  })
  .strict();
export const messageInput = z
  .object({
    body: z.string().max(16000),
    clientId: z.uuid(),
    replyToId: z.uuid().optional(),
    attachmentId: z.uuid().optional(),
  })
  .strict()
  .refine(
    (v) => v.body.trim().length > 0 || !!v.attachmentId,
    "Message is empty",
  );
export const themeNames = [
  "Luxury Cream",
  "Midnight Luxury",
  "Cyberpunk",
  "Arctic Silver",
  "Emerald Green",
  "Rose Gold",
  "Ocean Blue",
  "Purple Galaxy",
  "Sunset",
  "Glass Edition",
  "Crimson Red",
  "Classic Dark",
  "Classic Light",
] as const;
export type ThemeName = (typeof themeNames)[number];
export const profileInput = z
  .object({
    displayName: z.string().trim().min(1).max(80).optional(),
    bio: z.string().max(240).optional(),
    theme: z.enum(themeNames).optional(),
    accent: z
      .string()
      .regex(/^#[0-9a-fA-F]{6}$/)
      .nullable()
      .optional(),
    readReceipts: z.boolean().optional(),
    typingVisible: z.boolean().optional(),
  })
  .strict();
export const publicUserSelect = {
  id: true,
  username: true,
  displayName: true,
  bio: true,
} as const;
export type PublicUser = {
  id: string;
  username: string;
  displayName: string;
  bio: string;
};
export type Account = PublicUser & {
  role: string;
  theme: ThemeName;
  accent: string | null;
  readReceipts: boolean;
  typingVisible: boolean;
};
export type ChatMessage = {
  id: string;
  conversationId: string;
  senderId: string;
  clientId: string;
  body: string;
  createdAt: string;
  editedAt: string | null;
  deletedAt: string | null;
  sender: PublicUser;
  replyTo: { id: string; body: string; senderId: string } | null;
  attachment: {
    id: string;
    filename: string;
    mime: string;
    size: number;
  } | null;
  reactions: { userId: string; emoji: string }[];
  receipts: { userId: string; deliveredAt: string }[];
};
export type Chat = {
  id: string;
  kind: string;
  title: string | null;
  members: { userId: string; user: PublicUser; lastReadAt: string }[];
  messages: ChatMessage[];
  pinned: boolean;
  archived: boolean;
  muted: boolean;
  folder: string;
  unread: number;
};
// Each palette supplies the entire semantic component vocabulary, not just background.
export const themes: Record<
  ThemeName,
  Record<string, string>
> = Object.fromEntries(
  [
    [
      "Luxury Cream",
      "#f6f2ea",
      "#fffcf6",
      "#ede7da",
      "#242923",
      "#747768",
      "#89703e",
      "#ffffff",
      "#e4d7b7",
      "#dcd4c5",
    ],
    [
      "Midnight Luxury",
      "#111718",
      "#1b2223",
      "#232c2d",
      "#f2ead8",
      "#a6afaa",
      "#cbb584",
      "#293333",
      "#544a35",
      "#394346",
    ],
    [
      "Cyberpunk",
      "#111222",
      "#191a30",
      "#25253e",
      "#eeecff",
      "#b1b0d0",
      "#ed68ce",
      "#282842",
      "#63325e",
      "#414160",
    ],
    [
      "Arctic Silver",
      "#edf1f5",
      "#ffffff",
      "#e0e7ef",
      "#263646",
      "#65788b",
      "#527897",
      "#ffffff",
      "#cfdfef",
      "#c7d3df",
    ],
    [
      "Emerald Green",
      "#10251e",
      "#17352a",
      "#234638",
      "#e7f4df",
      "#afc8b9",
      "#92c69d",
      "#254b3c",
      "#365e43",
      "#3e6151",
    ],
    [
      "Rose Gold",
      "#f8efed",
      "#fff8f5",
      "#f0dfda",
      "#492f31",
      "#88696a",
      "#a56968",
      "#ffffff",
      "#efd0c6",
      "#dfc8c5",
    ],
    [
      "Ocean Blue",
      "#0d2334",
      "#12344a",
      "#21465b",
      "#e5f4fc",
      "#a5c6d9",
      "#6fbedc",
      "#20465a",
      "#296b85",
      "#345a70",
    ],
    [
      "Purple Galaxy",
      "#20172e",
      "#2a203a",
      "#3a2d4b",
      "#f4eafb",
      "#bdabcb",
      "#bc91dd",
      "#3a2b4e",
      "#60417b",
      "#51405f",
    ],
    [
      "Sunset",
      "#fff1e7",
      "#fff9f1",
      "#f7e0ce",
      "#563b32",
      "#967569",
      "#ae643e",
      "#ffffff",
      "#f3c7a6",
      "#e8cbb8",
    ],
    [
      "Glass Edition",
      "#e2eae8",
      "#f4faf9e6",
      "#d2e0dd",
      "#23483f",
      "#5f8177",
      "#497f70",
      "#ffffffcc",
      "#b9d8cf",
      "#b5cbc4",
    ],
    [
      "Crimson Red",
      "#28161a",
      "#361d23",
      "#492630",
      "#ffedf1",
      "#c99ca8",
      "#ee8fa3",
      "#47262f",
      "#6d3042",
      "#663b48",
    ],
    [
      "Classic Dark",
      "#17191c",
      "#22252a",
      "#2d3137",
      "#f3f4f5",
      "#abb0b9",
      "#a4b9d9",
      "#2c3036",
      "#364b67",
      "#41464e",
    ],
    [
      "Classic Light",
      "#f4f5f7",
      "#ffffff",
      "#e9ecf1",
      "#242b37",
      "#727b8a",
      "#4e668c",
      "#ffffff",
      "#dce5f3",
      "#d5dbe4",
    ],
  ].map(
    ([
      name,
      bg,
      panel,
      muted,
      text,
      subtle,
      accent,
      incoming,
      outgoing,
      border,
    ]) => [
      name,
      {
        "--bg": bg,
        "--panel": panel,
        "--muted": muted,
        "--text": text,
        "--subtle": subtle,
        "--accent": accent,
        "--incoming": incoming,
        "--outgoing": outgoing,
        "--border": border,
        "--error": name === "Luxury Cream" ? "#ab3535" : "#ca5555",
      },
    ],
  ),
) as unknown as Record<ThemeName, Record<string, string>>;
export function contrast(a: string, b: string) {
  const l = (h: string) => {
    const c = h
      .slice(1)
      .match(/../g)!
      .slice(0, 3)
      .map((v) => {
        const n = parseInt(v, 16) / 255;
        return n <= 0.04045 ? n / 12.92 : ((n + 0.055) / 1.055) ** 2.4;
      });
    return c[0] * 0.2126 + c[1] * 0.7152 + c[2] * 0.0722;
  };
  const x = l(a),
    y = l(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
