import { defineConfig, devices } from "@playwright/test";
import { config } from "dotenv";
config({ quiet: true });
export default defineConfig({
  testDir: "tests/browser",
  workers: 1,
  timeout: 60000,
  expect: { timeout: 10000 },
  use: {
    baseURL: "http://localhost:3100",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  webServer: [
    {
      command: "npm run start -w @nightspace/api",
      env: { NODE_ENV: "development" },
      url: "http://127.0.0.1:4100/api/ready",
      reuseExistingServer: false,
      timeout: 30000,
    },
    {
      command: "npm run start -w @nightspace/web",
      env: { NODE_ENV: "production" },
      url: "http://localhost:3100",
      reuseExistingServer: false,
      timeout: 60000,
    },
  ],
});
