# NIGHTSPACE — Local Development Environment (Windows)

This file documents the working local setup. It is safe to commit; it contains no
real credentials. Secrets live in `.env` (gitignored).

## Services required

| Service    | Requirement                                          | Current local state |
|------------|------------------------------------------------------|---------------------|
| PostgreSQL | 17.x, loopback port 5432, DB `nightspace`, user `nightspace` | Native install, `C:\Program Files\PostgreSQL\17`, Windows service running |
| Redis      | Any Redis-compatible server on port 56379 (loopback) | Memurai Developer 4.1.2 (Redis 7.2.5 compatible), Windows service "Memurai" running |

### Why Memurai, not Redis?
`Redis.Redis` on winget is still 3.0.504 (2015-era), and `download.redis.io` no longer
serves the classic Windows MSI (HTTP 403/404 for `Redis-x64-*.msi`). Memurai is a
native-Windows, Redis-compatible server that installs as a real Windows service
(no Docker needed) and speaks the Redis protocol that ioredis / socket.io-redis-adapter
consume. If you later install a different Redis-compatible server on 56379, just point
`REDIS_URL` at it.

## One-time setup that was already done on this machine

1. PostgreSQL 17 already present as a Windows service.
2. Created role + database:
   ```
   CREATE USER nightspace WITH PASSWORD '<see .env>' CREATEDB;
   CREATE DATABASE nightspace OWNER nightspace;
   ```
3. Installed Memurai Developer 4.1.2 (`winget install Memurai.MemuraiDeveloper`),
   reconfigured its port to **56379** to match `.env` / `.env.example`, and confirmed
   the "Memurai" Windows service is running and answering PING.

   Note: the first winget attempt can fail with MSI error 1603 / "Failed to create temp
   directory. Error code 5". If so, stop/repair the "Memurai" service, uninstall via
   `Get-CimInstance Win32_Product | ? Name -like 'Memurai*' | % Uninstall()`, and re-run
   `winget install` (or `msiexec /i <msi> /qn PORT=56379 ADD_FIREWALL_RULE=0`).

## Day-to-day commands (from the repo root)

```
npm install          # once
npm run db:generate  # regenerate Prisma client after schema changes
npm run db:migrate   # apply migrations
npm run db:seed      # optional: seed demo users aurora/atlas with the SEED_PASSWORD in .env
npm run dev          # starts API on :4100 and web on :3100 together (concurrently)
```

Stop: Ctrl-C in the `npm run dev` terminal. Both services are one tree (`concurrently -k`),
so Ctrl-C kills them both — no orphaned watchers.

## Ports

- API: 4100 (127.0.0.1 only)
- Web: 3100 (127.0.0.1 only)
- PostgreSQL: 5432 (127.0.0.1)
- Memurai/Redis: 56379 (127.0.0.1)

## .env

Copy from `.env.example` to `.env` and set real local-only values for:
- `DATABASE_URL` — must start with `postgresql://`
- `REDIS_URL` — must start with `redis://`
- `POSTGRES_PASSWORD`, `SEED_PASSWORD` — generate with `node -e "console.log(require('crypto').randomBytes(24).toString('urlsafe_base64'))"`

Both URLs are validated by Zod at API startup; missing values crash the API on purpose
(do not "fix" this by loosening the schema — that would hide real misconfiguration).

## Avoiding duplicate/stuck processes

- Never run `npm run dev` twice at once: `concurrently -k` guarantees both die together.
- If a previous session left a watcher on :4100, find it with:
  `netstat -ano | findstr :4100` -> take the PID -> `taskkill /F /PID <pid>`.
- `npm run env:check` is a quick way to confirm the whole `.env` parses before starting
  anything (`tsx scripts/check-env.ts`).

## Verified working (last full check)

- `GET /api/health` -> 200
- `GET /api/capabilities` -> 200
- `GET /api/ready` -> 200 (live `SELECT 1` against PostgreSQL + PING against Memurai)
- `POST /api/auth/register` -> 201, session cookie issued
- `GET /api/me` -> 200 with session cookie, 401 without one
- `POST /api/auth/login` (seeded user, correct password) -> 200; wrong password -> 401
- Frontend (Next.js on :3100) proxies `/api/*` and `/socket.io/*` to the API via the
  rewrites in `apps/web/next.config.ts` — verified `/api/capabilities`, `/api/auth/login`
  and `/api/me` all work through :3100 too.
- socket.io long-poll handshake with the correct Origin -> 200.

All CSRF checks on the API require `Origin: http://localhost:3100` (the configured
`WEB_ORIGIN`) for non-GET requests; that matches the real frontend origin, so no app
code change is needed — a raw curl/fetch from an unknown Origin getting 403 `CSRF_REJECTED`
is correct, intended behavior, not a bug.
