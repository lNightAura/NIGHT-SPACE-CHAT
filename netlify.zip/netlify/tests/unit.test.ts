import { describe, it, expect } from "vitest";
import {
  registration,
  messageInput,
  profileInput,
  themes,
  themeNames,
  contrast,
} from "@nightspace/shared";
import { detectMime } from "../apps/api/src/media.js";
import { decodeCursor } from "../apps/api/src/messages.js";
import { digest, isTrustedOrigin } from "../apps/api/src/security.js";
import { config } from "../apps/api/src/config.js";
import { randomUUID } from "node:crypto";
describe("shared validation and privacy primitives", () => {
  it("normalizes username and rejects weak password", () => {
    expect(
      registration.parse({
        username: "Aurora",
        displayName: "A",
        password: "long-unique-passphrase",
      }).username,
    ).toBe("aurora");
    expect(
      registration.safeParse({
        username: "aurora",
        displayName: "A",
        password: "short",
      }).success,
    ).toBe(false);
  });
  it("rejects extra privilege and identity fields", () => {
    expect(
      registration.safeParse({
        username: "aurora",
        displayName: "A",
        password: "long-unique-passphrase",
        role: "ADMIN",
      }).success,
    ).toBe(false);
    expect(
      messageInput.safeParse({
        body: "hi",
        clientId: randomUUID(),
        senderId: randomUUID(),
      }).success,
    ).toBe(false);
  });
  it("accepts mixed Unicode and requires nonempty messages", () => {
    const body = "سلام 🌙 hello مرحبا";
    expect(messageInput.parse({ body, clientId: randomUUID() }).body).toBe(
      body,
    );
    expect(
      messageInput.safeParse({ body: "  ", clientId: randomUUID() }).success,
    ).toBe(false);
  });
  it("rejects overlong message and unsafe theme tokens", () => {
    expect(
      messageInput.safeParse({
        body: "x".repeat(16001),
        clientId: randomUUID(),
      }).success,
    ).toBe(false);
    expect(
      profileInput.safeParse({ accent: "url(javascript:alert(1))" }).success,
    ).toBe(false);
  });
  it("defines all 13 complete semantic palettes", () => {
    expect(themeNames).toHaveLength(13);
    for (const name of themeNames) {
      expect(Object.keys(themes[name]).sort()).toEqual(
        [
          "--bg",
          "--panel",
          "--muted",
          "--text",
          "--subtle",
          "--accent",
          "--incoming",
          "--outgoing",
          "--border",
          "--error",
        ].sort(),
      );
      for (const color of Object.values(themes[name]))
        expect(color).toMatch(/^#[0-9a-f]{6}([0-9a-f]{2})?$/i);
    }
  });
  it("computes known contrast ratios", () => {
    expect(contrast("#000000", "#ffffff")).toBeCloseTo(21);
    expect(contrast("#ffffff", "#ffffff")).toBe(1);
  });
  it("hashes tokens without preserving the token", () => {
    expect(digest("secret")).toHaveLength(64);
    expect(digest("secret")).not.toContain("secret");
    expect(digest("secret")).toBe(digest("secret"));
  });
});
describe("media validation", () => {
  it("recognizes PNG JPEG PDF OGG WEBP MP4 magic signatures", () => {
    for (const [b, m] of [
      [Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), "image/png"],
      [Buffer.from([255, 216, 255]), "image/jpeg"],
      [Buffer.from("%PDF-1.7"), "application/pdf"],
      [Buffer.from("OggS"), "audio/ogg"],
      [Buffer.from("RIFF0000WEBP"), "image/webp"],
      [Buffer.from("0000ftypisom"), "video/mp4"],
    ] as const)
      expect(detectMime(b)).toBe(m);
  });
  it("rejects HTML scripts SVG executable and empty files", () => {
    for (const text of [
      "<html><script>alert(1)</script>",
      '<svg onload="evil()">',
      "MZexe",
      "",
    ])
      expect(detectMime(Buffer.from(text))).toBeNull();
  });
});
describe("cursor safety", () => {
  it("validates and decodes composite cursors", () => {
    const value = { createdAt: new Date().toISOString(), id: randomUUID() };
    const result = decodeCursor(
      Buffer.from(JSON.stringify(value)).toString("base64url"),
    );
    expect(result?.id).toBe(value.id);
    expect(decodeCursor(undefined)).toBeNull();
  });
  it("rejects malformed cursor without exposing internals", () => {
    for (const input of [
      "not json",
      "a".repeat(300),
      ["array"],
      Buffer.from('{"id":"sql"}').toString("base64url"),
    ])
      expect(() => decodeCursor(input)).toThrow("Invalid cursor");
  });
});
describe("origin trust", () => {
  it("accepts WEB_ORIGIN and its localhost/127.0.0.1互换 in dev", () => {
    expect(isTrustedOrigin(config.WEB_ORIGIN)).toBe(true);
    // In development both hostname forms are accepted.
    if (config.NODE_ENV !== "production") {
      try {
        const u = new URL(config.WEB_ORIGIN);
        const alt =
          u.hostname === "localhost"
            ? config.WEB_ORIGIN.replace("localhost", "127.0.0.1")
            : u.hostname === "127.0.0.1"
              ? config.WEB_ORIGIN.replace("127.0.0.1", "localhost")
              : null;
        if (alt) expect(isTrustedOrigin(alt)).toBe(true);
      } catch {
        /* non-URL origin — skip */
      }
    }
  });
  it("rejects null undefined and malicious origins", () => {
    expect(isTrustedOrigin(undefined)).toBe(false);
    expect(isTrustedOrigin(null as unknown as string)).toBe(false);
    expect(isTrustedOrigin("")).toBe(false);
    expect(isTrustedOrigin("https://evil.example")).toBe(false);
    expect(isTrustedOrigin("http://localhost:9999")).toBe(false);
  });
});
