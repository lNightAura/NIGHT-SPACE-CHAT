import express, {
  type Request,
  type Response,
  type NextFunction,
} from "express";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { ZodError, z } from "zod";
import { Prisma } from "@prisma/client";
import { publicUserSelect } from "@nightspace/shared";
import { auth } from "./auth.js";
import { conversations } from "./conversations.js";
import { messages } from "./messages.js";
import { media } from "./media.js";
import { db, redis } from "./db.js";
import { config } from "./config.js";
import {
  actor,
  cors,
  originGuard,
  authenticate,
  rate,
  id,
  audit,
} from "./security.js";
import { HttpError } from "./errors.js";
export function createApp() {
  const app = express();
  app.disable("x-powered-by");
  // Managed platforms terminate TLS at their edge. Trusting exactly one
  // forwarded hop keeps req.ip (and therefore per-IP rate limiting) accurate
  // without trusting arbitrary client-supplied X-Forwarded-For values.
  app.set(
    "trust proxy",
    config.TRUST_PROXY_PLATFORM
      ? 1
      : config.TRUST_PROXY_LOOPBACK
        ? "loopback"
        : false,
  );
  app.use(helmet());
  app.use(cookieParser());
  app.use((_req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    next();
  });
  app.use(express.json({ limit: "32kb" }));
  app.use(cors);
  app.use(originGuard);
  app.get("/api/health", (_req, res) =>
    res.json({ status: "ok", version: "0.1.0" }),
  );
  app.get("/api/ready", async (_req, res) => {
    await db.$queryRaw`SELECT 1`;
    await redis.ping();
    res.json({ database: "ok", redis: "ok" });
  });
  app.get("/api/capabilities", (_req, res) =>
    res.json({
      e2ee: false,
      serverReadableMessaging: !config.REQUIRE_E2EE,
      calls: false,
      captchaRequired: config.CAPTCHA_REQUIRED,
      captchaSiteKey: config.TURNSTILE_SITE_KEY,
      uploads:
        config.NODE_ENV !== "production" || config.ALLOW_PRODUCTION_UPLOADS,
    }),
  );
  app.use("/api", rate("api", 600), auth); // auth router protects remaining paths
  app.use("/api", authenticate, conversations, messages, media);
  app.get("/api/users", authenticate, rate("search", 30), async (req, res) => {
    const username = z
      .string()
      .min(3)
      .max(32)
      .regex(/^[a-zA-Z0-9_]+$/)
      .parse(req.query.username)
      .toLowerCase();
    const user = await db.user.findUnique({
      where: { username },
      select: publicUserSelect,
    });
    res.json(user ? [user] : []);
  });
  app.get("/api/blocks", authenticate, async (req, res) =>
    res.json(
      await db.block.findMany({
        where: { userId: actor(req).userId },
        select: { target: { select: publicUserSelect } },
      }),
    ),
  );
  app.post("/api/blocks", authenticate, rate("block", 30), async (req, res) => {
    const userId = actor(req).userId,
      targetId = id(req.body.userId);
    if (targetId === userId) throw new HttpError(400, "Cannot block yourself");
    res.json(
      await db.block.upsert({
        where: { userId_targetId: { userId, targetId } },
        create: { userId, targetId },
        update: {},
      }),
    );
  });
  app.delete("/api/blocks/:id", authenticate, async (req, res) => {
    await db.block.deleteMany({
      where: { userId: actor(req).userId, targetId: id(req.params.id) },
    });
    res.status(204).end();
  });
  app.post(
    "/api/reports",
    authenticate,
    rate("report", 5, 600),
    async (req, res) => {
      const input = z
        .object({
          targetId: z.uuid(),
          reason: z.string().trim().min(5).max(1000),
        })
        .strict()
        .parse(req.body);
      await db.report.create({
        data: { ...input, reporterId: actor(req).userId },
      });
      res.status(204).end();
    },
  );
  const admin = (req: Request, _res: Response, next: NextFunction) => {
    if (actor(req).role !== "ADMIN")
      return next(new HttpError(403, "Administrator required"));
    next();
  };
  app.get("/api/admin/metrics", authenticate, admin, async (req, res) => {
    await audit("ADMIN_METRICS_VIEWED", actor(req).userId);
    res.json({
      users: await db.user.count(),
      conversations: await db.conversation.count(),
      messages: await db.message.count(),
      activeSessions: await db.session.count({
        where: { expiresAt: { gt: new Date() } },
      }),
      recentSecurityEvents: await db.securityEvent.groupBy({
        by: ["action"],
        where: { createdAt: { gt: new Date(Date.now() - 3600000) } },
        _count: true,
      }),
      memoryBytes: process.memoryUsage().rss,
      waf: "not-integrated",
      turn: "not-integrated",
    });
  });
  app.get("/api/admin/reports", authenticate, admin, async (req, res) => {
    await audit("ADMIN_REPORTS_VIEWED", actor(req).userId);
    res.json(
      await db.report.findMany({ take: 100, orderBy: { createdAt: "desc" } }),
    );
  });
  app.use((_req, res) =>
    res.status(404).json({ error: "Not found", code: "NOT_FOUND" }),
  );
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (res.headersSent) {
      res.end();
      return;
    }
    if (err instanceof ZodError)
      return res
        .status(400)
        .json({ error: "Invalid input", code: "VALIDATION_ERROR" });
    if (err instanceof HttpError) {
      if (err.status === 429) res.setHeader("Retry-After", "60");
      return res
        .status(err.status)
        .json({ error: err.message, code: err.code });
    }
    if (
      err instanceof Prisma.PrismaClientKnownRequestError &&
      ["P2002", "P2003", "P2025"].includes(err.code)
    )
      return res.status(409).json({
        error: "Operation conflicts with current data",
        code: "CONFLICT",
      });
    if (
      err &&
      typeof err === "object" &&
      "code" in err &&
      err.code === "LIMIT_FILE_SIZE"
    )
      return res
        .status(413)
        .json({ error: "File too large", code: "FILE_TOO_LARGE" });
    if (
      err &&
      typeof err === "object" &&
      "type" in err &&
      err.type === "entity.too.large"
    )
      return res
        .status(413)
        .json({ error: "Request too large", code: "REQUEST_TOO_LARGE" });
    if (err instanceof SyntaxError)
      return res
        .status(400)
        .json({ error: "Invalid JSON", code: "VALIDATION_ERROR" });
    return res.status(503).json({
      error: "Service temporarily unavailable",
      code: "SERVICE_ERROR",
    });
  });
  return app;
}
