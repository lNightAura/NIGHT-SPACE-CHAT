import { createHash, randomBytes } from "node:crypto";
import type { Request, Response, NextFunction } from "express";
import { z } from "zod";
import { db, redis } from "./db.js";
import { config, cookieName } from "./config.js";
import { HttpError } from "./errors.js";
export type Identity = {
  userId: string;
  sessionId: string;
  role: string;
  expiresAt: Date;
};
declare module "express-serve-static-core" {
  interface Request {
    identity?: Identity;
  }
}
export const digest = (v: string) =>
  createHash("sha256").update(v).digest("hex");
export const id = (v: unknown) => z.uuid().parse(v);
export function actor(req: Request) {
  if (!req.identity) throw new HttpError(401, "Sign in required");
  return req.identity;
}
export const options = {
  httpOnly: true,
  secure: config.COOKIE_SECURE,
  sameSite: "lax" as const,
  path: "/",
};
export async function sessionFromToken(token: unknown) {
  if (typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token)) return null;
  const s = await db.session.findUnique({
    where: { tokenHash: digest(token) },
    include: { user: { select: { role: true } } },
  });
  return s && s.expiresAt > new Date()
    ? {
        userId: s.userId,
        sessionId: s.id,
        role: s.user.role,
        expiresAt: s.expiresAt,
      }
    : null;
}
export async function authenticate(
  req: Request,
  _res: Response,
  next: NextFunction,
) {
  try {
    const identity = await sessionFromToken(req.cookies?.[cookieName]);
    if (!identity) throw new HttpError(401, "Sign in required");
    req.identity = identity;
    next();
  } catch (e) {
    next(e);
  }
}
export function isTrustedOrigin(origin: string | undefined): boolean {
  if (!origin) return false;
  const allowed = [config.WEB_ORIGIN];
  // Permit localhost ↔ 127.0.0.1互换 in non-production only;
  // production keeps the single strict WEB_ORIGIN value.
  if (config.NODE_ENV !== "production") {
    try {
      const u = new URL(config.WEB_ORIGIN);
      const alt =
        u.hostname === "localhost"
          ? config.WEB_ORIGIN.replace("localhost", "127.0.0.1")
          : u.hostname === "127.0.0.1"
            ? config.WEB_ORIGIN.replace("127.0.0.1", "localhost")
            : null;
      if (alt) allowed.push(alt);
    } catch {
      /* malformed WEB_ORIGIN — fall back to strict match */
    }
  }
  return allowed.includes(origin);
}
// Cross-origin support for deployments where the browser talks to the API
// directly (a different origin from the frontend). The frontend normally
// proxies /api through its own origin, in which case no CORS header is
// needed; this keeps a direct HTTPS API origin usable without weakening the
// origin allow-list. Credentials are only echoed for a trusted origin, which
// is required for the session cookie to be sent cross-site.
export function cors(req: Request, res: Response, next: NextFunction) {
  const origin = req.get("origin");
  if (origin && isTrustedOrigin(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Vary", "Origin");
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET,HEAD,POST,PATCH,DELETE,OPTIONS",
    );
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Content-Type, Accept, X-Requested-With",
    );
    res.setHeader("Access-Control-Max-Age", "600");
  }
  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }
  next();
}
export function originGuard(req: Request, _res: Response, next: NextFunction) {
  if (
    !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
    !isTrustedOrigin(req.get("origin"))
  )
    return next(new HttpError(403, "Origin rejected", "CSRF_REJECTED"));
  next();
}
export async function limitKey(key: string, limit: number, seconds: number) {
  const k = "ns:rate:" + digest(key);
  const n = Number(
    await redis.eval(
      "local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],ARGV[1]) end; return n",
      1,
      k,
      seconds,
    ),
  );
  if (n > limit)
    throw new HttpError(429, "Please slow down and retry", "RATE_LIMITED");
}
export function rate(scope: string, count: number, seconds = 60) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    try {
      await limitKey(`${scope}:ip:${req.ip}`, count, seconds);
      if (req.identity)
        await limitKey(`${scope}:user:${req.identity.userId}`, count, seconds);
      next();
    } catch (e) {
      next(e);
    }
  };
}
export async function issueSession(userId: string, res: Response) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + config.SESSION_DAYS * 86400000);
  await db.session.create({
    data: { tokenHash: digest(token), userId, expiresAt },
  });
  res.cookie(cookieName, token, { ...options, expires: expiresAt });
}
export async function captcha(token: string | undefined, action: string) {
  if (!config.CAPTCHA_REQUIRED) return;
  if (!token)
    throw new HttpError(
      400,
      "Complete the security challenge",
      "CAPTCHA_REQUIRED",
    );
  const response = await fetch(
    "https://challenges.cloudflare.com/turnstile/v0/siteverify",
    {
      method: "POST",
      body: new URLSearchParams({
        secret: config.TURNSTILE_SECRET,
        response: token,
      }),
      signal: AbortSignal.timeout(6000),
    },
  );
  const result = (await response.json()) as {
    success?: boolean;
    hostname?: string;
    action?: string;
  };
  if (
    !response.ok ||
    !result.success ||
    result.hostname !== config.TURNSTILE_HOSTNAME ||
    result.action !== action
  )
    throw new HttpError(400, "Security challenge rejected", "CAPTCHA_FAILED");
  const fresh = await redis.set(
    "ns:captcha:" + digest(token),
    "1",
    "EX",
    300,
    "NX",
  );
  if (!fresh) throw new HttpError(400, "Security challenge already used");
}
export async function membership(userId: string, conversationId: string) {
  const m = await db.member.findUnique({
    where: { userId_conversationId: { userId, conversationId } },
  });
  if (!m) throw new HttpError(404, "Conversation not found");
  return m;
}
export async function canSend(userId: string, conversationId: string) {
  await membership(userId, conversationId);
  const members = await db.member.findMany({
    where: { conversationId },
    select: { userId: true },
  });
  const others = members.map((m) => m.userId).filter((id) => id !== userId);
  const blocked = await db.block.findFirst({
    where: {
      OR: [
        { userId, targetId: { in: others } },
        { targetId: userId, userId: { in: others } },
      ],
    },
  });
  if (blocked)
    throw new HttpError(403, "Messaging is unavailable for this conversation");
}
export async function audit(action: string, actorId?: string) {
  await db.securityEvent.create({ data: { action, actorId } });
}
