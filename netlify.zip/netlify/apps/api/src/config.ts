import { config as dotenv } from "dotenv";
import { fileURLToPath } from "node:url";
import { z } from "zod";
dotenv({
  path: fileURLToPath(new URL("../../../.env", import.meta.url)),
  quiet: true,
});
// Compiled dist and src have identical path depth.
const bool = z.enum(["true", "false"]).transform((v) => v === "true");
const schema = z.object({
  NODE_ENV: z
    .enum(["development", "test", "production"])
    .default("development"),
  // Containers and managed platforms route to the process over the pod
  // interface, so a loopback bind is unreachable from the platform edge.
  // Production therefore defaults to all interfaces; development stays
  // loopback-only.
  API_HOST: z
    .string()
    .default(process.env.NODE_ENV === "production" ? "0.0.0.0" : "127.0.0.1"),
  // Managed platforms inject PORT and expect the process to honour it.
  API_PORT: z.coerce.number().int().min(1).max(65535).default(
    Number(process.env.PORT) || 4100,
  ),
  TRUST_PROXY_LOOPBACK: bool.default(false),
  // Platforms terminate TLS at their edge and forward the client address in
  // X-Forwarded-For. Without trusting that hop every request appears to come
  // from the proxy, which collapses per-IP rate limiting into one bucket.
  TRUST_PROXY_PLATFORM: bool.default(
    process.env.NODE_ENV === "production",
  ),
  WEB_ORIGIN: z.url().default("http://localhost:3100"),
  DATABASE_URL: z.string().startsWith("postgresql://"),
  // Managed Redis is reached over TLS with rediss://. ioredis negotiates TLS
  // from the scheme, so both forms are valid and must not be rejected.
  REDIS_URL: z
    .string()
    .refine(
      (v) => v.startsWith("redis://") || v.startsWith("rediss://"),
      "REDIS_URL must start with redis:// or rediss://",
    ),
  SESSION_DAYS: z.coerce.number().int().min(1).max(30).default(14),
  COOKIE_SECURE: bool.default(false),
  // A single cookie name that works on both schemes. __Host- requires Secure,
  // Path=/ and no Domain, which is exactly what a proxied HTTPS deployment
  // needs; using it only when Secure is set keeps local HTTP working.
  UPLOAD_DIR: z.string().default("./uploads"),
  MAX_UPLOAD_MB: z.coerce.number().int().min(1).max(25).default(10),
  ALLOW_PRODUCTION_UPLOADS: bool.default(false),
  REQUIRE_E2EE: bool.default(false),
  CAPTCHA_REQUIRED: bool.default(false),
  TURNSTILE_SECRET: z.string().default(""),
  TURNSTILE_SITE_KEY: z.string().default(""),
  TURNSTILE_HOSTNAME: z.string().default("localhost"),
});
export const config = schema.parse(process.env);
if (config.NODE_ENV === "production") {
  const missing: string[] = [];
  if (!config.COOKIE_SECURE) missing.push("COOKIE_SECURE=true");
  if (!config.WEB_ORIGIN.startsWith("https://"))
    missing.push("WEB_ORIGIN=https://<your frontend origin>");
  if (!config.CAPTCHA_REQUIRED) missing.push("CAPTCHA_REQUIRED=true");
  if (!config.TURNSTILE_SECRET) missing.push("TURNSTILE_SECRET=<cloudflare turnstile secret>");
  if (!config.TURNSTILE_SITE_KEY) missing.push("TURNSTILE_SITE_KEY=<cloudflare turnstile site key>");
  if (missing.length)
    throw new Error(
      "Production requires HTTPS, secure cookies and configured CAPTCHA. Missing or invalid: " +
        missing.join(", "),
    );
}
export const cookieName = config.COOKIE_SECURE
  ? "__Host-nightspace"
  : "nightspace";
