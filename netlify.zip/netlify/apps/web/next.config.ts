import { config as loadEnv } from "dotenv";
import { fileURLToPath } from "node:url";
loadEnv({
  path: fileURLToPath(new URL("../../.env", import.meta.url)),
  quiet: true,
});
import type { NextConfig } from "next";

// The rewrite target below is resolved when this config runs, and Next bakes
// the result into .next/routes-manifest.json. On a hosting platform that
// manifest is evaluated in the build/function runtime, where 127.0.0.1 is the
// container itself -- never the API. A loopback target therefore ships a
// frontend that cannot reach its backend, which is exactly the
// "Network request failed" state. Fail the build instead of shipping it.
const api = process.env.API_INTERNAL_URL || "http://127.0.0.1:4100";

function isLoopback(value: string): boolean {
  try {
    const host = new URL(value).hostname;
    return (
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "0.0.0.0" ||
      host === "::1" ||
      host === "[::1]"
    );
  } catch {
    return false;
  }
}

const configured = process.env.API_INTERNAL_URL;

// Two distinct situations, handled differently on purpose:
//
// 1. API_INTERNAL_URL is unset. The build must still succeed so the site can
//    be produced and inspected; the loopback default is only a development
//    fallback. Warn loudly rather than failing the whole deploy.
// 2. API_INTERNAL_URL is explicitly set to a loopback address. That is an
//    operator misconfiguration which would silently ship a frontend that
//    cannot reach its API, so refuse to build it.
if (configured && isLoopback(configured)) {
  throw new Error(
    [
      "API_INTERNAL_URL is explicitly set to a loopback address (" + configured + ").",
      "This build would bake an unreachable API target into the deployment.",
      "Set API_INTERNAL_URL to the public HTTPS origin of the deployed API,",
      "for example https://nightspace-api.up.railway.app, then rebuild.",
    ].join(" "),
  );
}

if (!configured) {
  console.warn(
    [
      "",
      "  [nightspace] API_INTERNAL_URL is not set.",
      "  The build is using the development fallback " + api + ".",
      "  The deployed site will NOT reach a backend until you set",
      "  API_INTERNAL_URL to the public HTTPS origin of the API and rebuild.",
      "",
    ].join("\n"),
  );
}

const config: NextConfig = {
  poweredByHeader: false,
  skipTrailingSlashRedirect: true,
  async rewrites() {
    return [
      { source: "/api/:path*", destination: `${api}/api/:path*` },
      { source: "/socket.io/:path*", destination: `${api}/socket.io/:path*` },
    ];
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "same-origin" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Permissions-Policy", value: "camera=(), microphone=()" },
          {
            key: "Content-Security-Policy",
            value:
              "default-src 'self'; script-src 'self' 'unsafe-inline' https://challenges.cloudflare.com" +
              (process.env.NODE_ENV === "development" ? " 'unsafe-eval'" : "") +
              "; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' ws: wss: https://challenges.cloudflare.com; frame-src https://challenges.cloudflare.com; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
          },
        ],
      },
    ];
  },
};
export default config;
